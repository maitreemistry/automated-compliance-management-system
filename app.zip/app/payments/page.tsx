import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { DashboardHeader } from "@/components/dashboard-header"
import { PaymentForm } from "@/components/payment-form"
import { Badge } from "@/components/ui/badge"
import { CreditCard, Download } from "lucide-react"

export default function PaymentsPage() {
  return (
    <div className="flex flex-col">
      <DashboardHeader heading="Payments" text="Make payments and view your payment history.">
        <Button variant="outline" size="sm" className="gap-1">
          <Download className="h-4 w-4" />
          <span className="hidden sm:inline">Download Statement</span>
        </Button>
      </DashboardHeader>

      <main className="flex-1 space-y-4 p-4 md:p-8 pt-6">
        <Tabs defaultValue="make-payment" className="space-y-4">
          <TabsList>
            <TabsTrigger value="make-payment">Make a Payment</TabsTrigger>
            <TabsTrigger value="payment-history">Payment History</TabsTrigger>
            <TabsTrigger value="scheduled-payments">Scheduled Payments</TabsTrigger>
          </TabsList>

          <TabsContent value="make-payment">
            <div className="grid gap-4 md:grid-cols-7">
              <Card className="md:col-span-3">
                <CardHeader>
                  <CardTitle>Make a Payment</CardTitle>
                  <CardDescription>Choose a loan and payment method</CardDescription>
                </CardHeader>
                <CardContent>
                  <PaymentForm />
                </CardContent>
              </Card>

              <Card className="md:col-span-4">
                <CardHeader>
                  <CardTitle>Payment Summary</CardTitle>
                  <CardDescription>Your upcoming payments</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="rounded-lg border p-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <div className="rounded-full bg-primary/10 p-2">
                            <CreditCard className="h-4 w-4 text-primary" />
                          </div>
                          <div>
                            <h3 className="font-medium">Personal Loan #12345</h3>
                            <p className="text-sm text-muted-foreground">Due Apr 15, 2025</p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="font-medium">$1,231.00</p>
                          <p className="text-xs text-muted-foreground">Minimum payment</p>
                        </div>
                      </div>
                    </div>

                    <div className="rounded-lg border p-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <div className="rounded-full bg-primary/10 p-2">
                            <CreditCard className="h-4 w-4 text-primary" />
                          </div>
                          <div>
                            <h3 className="font-medium">Auto Loan #54321</h3>
                            <p className="text-sm text-muted-foreground">Due Apr 1, 2025</p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="font-medium">$543.21</p>
                          <p className="text-xs text-muted-foreground">Minimum payment</p>
                        </div>
                      </div>
                    </div>

                    <div className="rounded-lg border p-4 bg-muted/30">
                      <h3 className="font-medium mb-2">Payment Tips</h3>
                      <ul className="text-sm space-y-2">
                        <li>• Set up automatic payments to avoid late fees</li>
                        <li>• Paying more than the minimum can reduce your overall interest</li>
                        <li>• Payments are processed within 1-2 business days</li>
                      </ul>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="payment-history">
            <Card>
              <CardHeader>
                <CardTitle>Payment History</CardTitle>
                <CardDescription>View your recent payment activity</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="rounded-lg border">
                  <div className="grid grid-cols-1 md:grid-cols-6 p-4 text-sm font-medium">
                    <div>Loan</div>
                    <div>Amount</div>
                    <div>Date</div>
                    <div>Method</div>
                    <div>Status</div>
                    <div></div>
                  </div>
                  <div className="divide-y">
                    <div className="grid grid-cols-1 md:grid-cols-6 p-4 text-sm items-center">
                      <div>Personal Loan #12345</div>
                      <div>$1,231.00</div>
                      <div>Mar 15, 2025</div>
                      <div>Credit Card</div>
                      <div>
                        <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                          Completed
                        </Badge>
                      </div>
                      <div className="text-right">
                        <Button variant="ghost" size="sm">
                          Receipt
                        </Button>
                      </div>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-6 p-4 text-sm items-center">
                      <div>Auto Loan #54321</div>
                      <div>$543.21</div>
                      <div>Mar 1, 2025</div>
                      <div>Bank Account</div>
                      <div>
                        <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                          Completed
                        </Badge>
                      </div>
                      <div className="text-right">
                        <Button variant="ghost" size="sm">
                          Receipt
                        </Button>
                      </div>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-6 p-4 text-sm items-center">
                      <div>Personal Loan #12345</div>
                      <div>$1,231.00</div>
                      <div>Feb 15, 2025</div>
                      <div>Credit Card</div>
                      <div>
                        <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                          Completed
                        </Badge>
                      </div>
                      <div className="text-right">
                        <Button variant="ghost" size="sm">
                          Receipt
                        </Button>
                      </div>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-6 p-4 text-sm items-center">
                      <div>Auto Loan #54321</div>
                      <div>$543.21</div>
                      <div>Feb 1, 2025</div>
                      <div>Bank Account</div>
                      <div>
                        <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                          Completed
                        </Badge>
                      </div>
                      <div className="text-right">
                        <Button variant="ghost" size="sm">
                          Receipt
                        </Button>
                      </div>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-6 p-4 text-sm items-center">
                      <div>Personal Loan #12345</div>
                      <div>$1,231.00</div>
                      <div>Jan 15, 2025</div>
                      <div>Credit Card</div>
                      <div>
                        <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                          Completed
                        </Badge>
                      </div>
                      <div className="text-right">
                        <Button variant="ghost" size="sm">
                          Receipt
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="scheduled-payments">
            <Card>
              <CardHeader>
                <CardTitle>Scheduled Payments</CardTitle>
                <CardDescription>View and manage your upcoming scheduled payments</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="rounded-lg border">
                  <div className="grid grid-cols-1 md:grid-cols-6 p-4 text-sm font-medium">
                    <div>Loan</div>
                    <div>Amount</div>
                    <div>Scheduled Date</div>
                    <div>Method</div>
                    <div>Status</div>
                    <div></div>
                  </div>
                  <div className="divide-y">
                    <div className="grid grid-cols-1 md:grid-cols-6 p-4 text-sm items-center">
                      <div>Auto Loan #54321</div>
                      <div>$543.21</div>
                      <div>Apr 1, 2025</div>
                      <div>Bank Account</div>
                      <div>
                        <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                          Scheduled
                        </Badge>
                      </div>
                      <div className="text-right">
                        <Button variant="ghost" size="sm">
                          Cancel
                        </Button>
                      </div>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-6 p-4 text-sm items-center">
                      <div>Personal Loan #12345</div>
                      <div>$1,231.00</div>
                      <div>Apr 15, 2025</div>
                      <div>Credit Card</div>
                      <div>
                        <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                          Scheduled
                        </Badge>
                      </div>
                      <div className="text-right">
                        <Button variant="ghost" size="sm">
                          Cancel
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="mt-6 rounded-lg border p-4 bg-muted/30">
                  <h3 className="font-medium mb-2">Automatic Payments</h3>
                  <p className="text-sm mb-4">You have automatic payments set up for the following loans:</p>

                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium">Auto Loan #54321</p>
                        <p className="text-xs text-muted-foreground">Monthly on the 1st</p>
                      </div>
                      <Button variant="outline" size="sm">
                        Manage
                      </Button>
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium">Personal Loan #12345</p>
                        <p className="text-xs text-muted-foreground">Monthly on the 15th</p>
                      </div>
                      <Button variant="outline" size="sm">
                        Manage
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}

