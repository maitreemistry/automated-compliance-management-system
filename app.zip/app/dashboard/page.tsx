import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { AlertCircle, Bell, CreditCard, DollarSign, FileText, PiggyBank } from "lucide-react"
import Link from "next/link"
import { DashboardChart } from "@/components/dashboard-chart"
import { DashboardHeader } from "@/components/dashboard-header"

export default function DashboardPage() {
  return (
    <div className="flex flex-col">
      <DashboardHeader heading="Dashboard" text="View and manage your loans and payments.">
        <Button variant="outline" size="sm" className="ml-auto gap-1">
          <Bell className="h-4 w-4" />
          <span className="hidden sm:inline">Notifications</span>
        </Button>
        <Link href="/apply">
          <Button size="sm" className="gap-1">
            <FileText className="h-4 w-4" />
            <span className="hidden sm:inline">New Application</span>
          </Button>
        </Link>
      </DashboardHeader>

      <main className="flex-1 space-y-4 p-4 md:p-8 pt-6">
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Balance</CardTitle>
              <DollarSign className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">$45,231.89</div>
              <p className="text-xs text-muted-foreground">+20.1% from last month</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Active Loans</CardTitle>
              <FileText className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">2</div>
              <p className="text-xs text-muted-foreground">1 pending approval</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Next Payment</CardTitle>
              <CreditCard className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">$1,231.00</div>
              <p className="text-xs text-muted-foreground">Due in 15 days</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Available Credit</CardTitle>
              <PiggyBank className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">$25,000.00</div>
              <p className="text-xs text-muted-foreground">Pre-approved amount</p>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="overview" className="space-y-4">
          <TabsList>
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="loans">Loans</TabsTrigger>
            <TabsTrigger value="payments">Payments</TabsTrigger>
          </TabsList>
          <TabsContent value="overview" className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
              <Card className="lg:col-span-4">
                <CardHeader>
                  <CardTitle>Payment History</CardTitle>
                </CardHeader>
                <CardContent className="pl-2">
                  <DashboardChart />
                </CardContent>
              </Card>
              <Card className="lg:col-span-3">
                <CardHeader>
                  <CardTitle>Recent Activity</CardTitle>
                  <CardDescription>Your recent loan and payment activity</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center">
                      <div className="flex items-center justify-center rounded-full bg-primary/10 p-2 mr-2">
                        <CreditCard className="h-4 w-4 text-primary" />
                      </div>
                      <div className="flex-1 space-y-1">
                        <p className="text-sm font-medium leading-none">Payment Received</p>
                        <p className="text-xs text-muted-foreground">Personal Loan #12345</p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-medium">$1,231.00</p>
                        <p className="text-xs text-muted-foreground">Mar 15, 2025</p>
                      </div>
                    </div>
                    <div className="flex items-center">
                      <div className="flex items-center justify-center rounded-full bg-primary/10 p-2 mr-2">
                        <FileText className="h-4 w-4 text-primary" />
                      </div>
                      <div className="flex-1 space-y-1">
                        <p className="text-sm font-medium leading-none">Loan Application</p>
                        <p className="text-xs text-muted-foreground">Home Improvement Loan</p>
                      </div>
                      <div className="text-right">
                        <Badge variant="outline" className="bg-amber-50 text-amber-700 border-amber-200">
                          Pending
                        </Badge>
                        <p className="text-xs text-muted-foreground">Mar 10, 2025</p>
                      </div>
                    </div>
                    <div className="flex items-center">
                      <div className="flex items-center justify-center rounded-full bg-primary/10 p-2 mr-2">
                        <AlertCircle className="h-4 w-4 text-primary" />
                      </div>
                      <div className="flex-1 space-y-1">
                        <p className="text-sm font-medium leading-none">Payment Due Soon</p>
                        <p className="text-xs text-muted-foreground">Auto Loan #54321</p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-medium">$543.21</p>
                        <p className="text-xs text-muted-foreground">Due Apr 1, 2025</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
              <Card className="lg:col-span-4">
                <CardHeader>
                  <CardTitle>Active Loans</CardTitle>
                  <CardDescription>Your current loan portfolio</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="space-y-1">
                          <p className="text-sm font-medium leading-none">Personal Loan #12345</p>
                          <p className="text-xs text-muted-foreground">Started Jan 15, 2025</p>
                        </div>
                        <div className="text-right">
                          <p className="text-sm font-medium">$25,000.00</p>
                          <p className="text-xs text-muted-foreground">5.9% APR</p>
                        </div>
                      </div>
                      <div className="space-y-1">
                        <div className="flex items-center justify-between text-xs">
                          <span>Progress</span>
                          <span>35%</span>
                        </div>
                        <Progress value={35} className="h-2" />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="space-y-1">
                          <p className="text-sm font-medium leading-none">Auto Loan #54321</p>
                          <p className="text-xs text-muted-foreground">Started Nov 10, 2024</p>
                        </div>
                        <div className="text-right">
                          <p className="text-sm font-medium">$18,500.00</p>
                          <p className="text-xs text-muted-foreground">4.5% APR</p>
                        </div>
                      </div>
                      <div className="space-y-1">
                        <div className="flex items-center justify-between text-xs">
                          <span>Progress</span>
                          <span>62%</span>
                        </div>
                        <Progress value={62} className="h-2" />
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card className="lg:col-span-3">
                <CardHeader>
                  <CardTitle>Upcoming Payments</CardTitle>
                  <CardDescription>Your scheduled payments for the next 30 days</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center">
                      <div className="flex-1 space-y-1">
                        <p className="text-sm font-medium leading-none">Auto Loan #54321</p>
                        <p className="text-xs text-muted-foreground">Due Apr 1, 2025</p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-medium">$543.21</p>
                        <Button variant="outline" size="sm">
                          Pay Now
                        </Button>
                      </div>
                    </div>
                    <div className="flex items-center">
                      <div className="flex-1 space-y-1">
                        <p className="text-sm font-medium leading-none">Personal Loan #12345</p>
                        <p className="text-xs text-muted-foreground">Due Apr 15, 2025</p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-medium">$1,231.00</p>
                        <Button variant="outline" size="sm">
                          Pay Now
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          <TabsContent value="loans" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Your Loans</CardTitle>
                <CardDescription>View and manage all your current and past loans</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="rounded-lg border p-4">
                    <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                      <div>
                        <h3 className="font-medium">Personal Loan #12345</h3>
                        <p className="text-sm text-muted-foreground">Started Jan 15, 2025</p>
                      </div>
                      <div className="flex flex-col sm:flex-row gap-2 sm:items-center">
                        <Badge className="w-fit">Active</Badge>
                        <span className="text-sm">$25,000.00 at 5.9% APR</span>
                      </div>
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm">
                          Details
                        </Button>
                        <Button size="sm">Make Payment</Button>
                      </div>
                    </div>
                    <div className="mt-4 space-y-1">
                      <div className="flex items-center justify-between text-xs">
                        <span>Progress</span>
                        <span>35% ($8,750.00 paid)</span>
                      </div>
                      <Progress value={35} className="h-2" />
                    </div>
                  </div>

                  <div className="rounded-lg border p-4">
                    <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                      <div>
                        <h3 className="font-medium">Auto Loan #54321</h3>
                        <p className="text-sm text-muted-foreground">Started Nov 10, 2024</p>
                      </div>
                      <div className="flex flex-col sm:flex-row gap-2 sm:items-center">
                        <Badge className="w-fit">Active</Badge>
                        <span className="text-sm">$18,500.00 at 4.5% APR</span>
                      </div>
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm">
                          Details
                        </Button>
                        <Button size="sm">Make Payment</Button>
                      </div>
                    </div>
                    <div className="mt-4 space-y-1">
                      <div className="flex items-center justify-between text-xs">
                        <span>Progress</span>
                        <span>62% ($11,470.00 paid)</span>
                      </div>
                      <Progress value={62} className="h-2" />
                    </div>
                  </div>

                  <div className="rounded-lg border p-4 bg-muted/30">
                    <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                      <div>
                        <h3 className="font-medium">Home Improvement Loan</h3>
                        <p className="text-sm text-muted-foreground">Applied Mar 10, 2025</p>
                      </div>
                      <div className="flex flex-col sm:flex-row gap-2 sm:items-center">
                        <Badge variant="outline" className="bg-amber-50 text-amber-700 border-amber-200 w-fit">
                          Pending
                        </Badge>
                        <span className="text-sm">$15,000.00 at 6.5% APR</span>
                      </div>
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm">
                          View Application
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          <TabsContent value="payments" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Payment History</CardTitle>
                <CardDescription>View your recent payments and upcoming due dates</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="rounded-lg border">
                    <div className="grid grid-cols-1 md:grid-cols-5 p-4 text-sm font-medium">
                      <div>Loan</div>
                      <div>Amount</div>
                      <div>Date</div>
                      <div>Status</div>
                      <div></div>
                    </div>
                    <div className="divide-y">
                      <div className="grid grid-cols-1 md:grid-cols-5 p-4 text-sm items-center">
                        <div>Personal Loan #12345</div>
                        <div>$1,231.00</div>
                        <div>Mar 15, 2025</div>
                        <div>
                          <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                            Completed
                          </Badge>
                        </div>
                        <div className="text-right">
                          <Button variant="ghost" size="sm">
                            Receipt
                          </Button>
                        </div>
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-5 p-4 text-sm items-center">
                        <div>Auto Loan #54321</div>
                        <div>$543.21</div>
                        <div>Mar 1, 2025</div>
                        <div>
                          <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                            Completed
                          </Badge>
                        </div>
                        <div className="text-right">
                          <Button variant="ghost" size="sm">
                            Receipt
                          </Button>
                        </div>
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-5 p-4 text-sm items-center">
                        <div>Personal Loan #12345</div>
                        <div>$1,231.00</div>
                        <div>Feb 15, 2025</div>
                        <div>
                          <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                            Completed
                          </Badge>
                        </div>
                        <div className="text-right">
                          <Button variant="ghost" size="sm">
                            Receipt
                          </Button>
                        </div>
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-5 p-4 text-sm items-center">
                        <div>Auto Loan #54321</div>
                        <div>$543.21</div>
                        <div>Feb 1, 2025</div>
                        <div>
                          <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                            Completed
                          </Badge>
                        </div>
                        <div className="text-right">
                          <Button variant="ghost" size="sm">
                            Receipt
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="rounded-lg border p-4">
                    <h3 className="font-medium mb-4">Upcoming Payments</h3>
                    <div className="space-y-4">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                        <div>
                          <p className="font-medium">Auto Loan #54321</p>
                          <p className="text-sm text-muted-foreground">Due Apr 1, 2025</p>
                        </div>
                        <div className="flex items-center gap-4">
                          <p className="font-medium">$543.21</p>
                          <Button size="sm">Pay Now</Button>
                        </div>
                      </div>
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                        <div>
                          <p className="font-medium">Personal Loan #12345</p>
                          <p className="text-sm text-muted-foreground">Due Apr 15, 2025</p>
                        </div>
                        <div className="flex items-center gap-4">
                          <p className="font-medium">$1,231.00</p>
                          <Button size="sm">Pay Now</Button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}

