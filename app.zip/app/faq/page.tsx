import type { Metadata } from "next"
import Link from "next/link"
import { ArrowRight } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"

// Update the metadata
export const metadata: Metadata = {
  title: "FAQ | DigiLoan",
  description: "Frequently asked questions about our digital lending platform",
}

export default function FAQPage() {
  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="bg-gradient-to-b from-muted/50 to-background py-16 md:py-24">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center text-center space-y-4">
            <div className="space-y-2">
              <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">
                Frequently Asked Questions
              </h1>
              <p className="mx-auto max-w-[700px] text-muted-foreground md:text-xl">
                Find answers to common questions about our digital lending platform
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-12 md:py-20">
        <div className="container px-4 md:px-6">
          <div className="mx-auto max-w-3xl space-y-8">
            <Accordion type="single" collapsible className="w-full">
              <AccordionItem value="item-1">
                <AccordionTrigger>What is digital lending?</AccordionTrigger>
                <AccordionContent>
                  Digital lending refers to the process of providing loans through online platforms, allowing borrowers
                  to apply for and manage loans entirely online.
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-2">
                <AccordionTrigger>How do I apply for a loan?</AccordionTrigger>
                <AccordionContent>
                  You can apply for a loan by filling out our online application form, providing necessary details such
                  as your income, employment status, and the amount you wish to borrow.
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-3">
                <AccordionTrigger>What documents do I need to submit?</AccordionTrigger>
                <AccordionContent>
                  Typically, you will need to provide identification documents (e.g., Aadhar card, PAN card), proof of
                  income (e.g., salary slips or bank statements), and any other documents specified during the
                  application process.
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-4">
                <AccordionTrigger>How is my creditworthiness assessed?</AccordionTrigger>
                <AccordionContent>
                  We use advanced algorithms and machine learning models to evaluate your creditworthiness based on your
                  financial history, income details, and alternative data sources.
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-5">
                <AccordionTrigger>What are the interest rates on loans?</AccordionTrigger>
                <AccordionContent>
                  Interest rates vary based on the type of loan and your credit profile. You can view specific rates
                  during the application process or in your loan agreement.
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-6">
                <AccordionTrigger>How long does it take to get approved for a loan?</AccordionTrigger>
                <AccordionContent>
                  The approval process is typically automated and can take just a few minutes to a few hours, depending
                  on the completeness of your application.
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-7">
                <AccordionTrigger>When will I receive my loan funds?</AccordionTrigger>
                <AccordionContent>
                  Once approved, funds are usually disbursed to your bank account within 24 hours, provided all required
                  documentation is submitted.
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-8">
                <AccordionTrigger>What happens if I miss a payment?</AccordionTrigger>
                <AccordionContent>
                  Missing a payment may result in late fees and could affect your credit score. We recommend contacting
                  our support team to discuss options if you anticipate missing a payment.
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-9">
                <AccordionTrigger>Are there any prepayment penalties?</AccordionTrigger>
                <AccordionContent>
                  Prepayment penalties vary by loan type. Please refer to your loan agreement for specific terms
                  regarding prepayment options.
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-10">
                <AccordionTrigger>How can I ensure my data is secure?</AccordionTrigger>
                <AccordionContent>
                  We implement industry-standard security measures, including data encryption and two-factor
                  authentication, to protect your personal information.
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-11">
                <AccordionTrigger>What should I do if I have a complaint or issue with my loan?</AccordionTrigger>
                <AccordionContent>
                  You can reach out to our customer support team through the contact information provided on our website
                  or via the help section in your dashboard.
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-12">
                <AccordionTrigger>Are there any fees associated with taking out a loan?</AccordionTrigger>
                <AccordionContent>
                  Yes, there may be processing fees or other charges associated with your loan. All applicable fees will
                  be outlined in your loan agreement.
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-13">
                <AccordionTrigger>Can I modify my loan terms after approval?</AccordionTrigger>
                <AccordionContent>
                  Changes to loan terms may be possible but are subject to approval based on our policies. Please
                  contact customer support for assistance.
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-14">
                <AccordionTrigger>What regulations govern digital lending in my region?</AccordionTrigger>
                <AccordionContent>
                  Our platform complies with all applicable regulations set forth by relevant financial authorities,
                  including KYC/AML guidelines as mandated by the Reserve Bank of India (RBI).
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-15">
                <AccordionTrigger>How can I exit or cancel my loan agreement?</AccordionTrigger>
                <AccordionContent>
                  If you wish to exit or cancel your loan agreement within the cooling-off period, please contact our
                  customer support team for guidance on the process.
                </AccordionContent>
              </AccordionItem>
            </Accordion>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-muted py-12 md:py-16">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center gap-4 text-center">
            <h2 className="text-2xl font-bold tracking-tighter sm:text-3xl">Still Have Questions?</h2>
            <p className="max-w-[700px] text-muted-foreground">
              Our support team is here to help. Contact us for personalized assistance with your loan needs.
            </p>
            <div className="flex flex-col gap-2 min-[400px]:flex-row">
              <Link href="/contact">
                <Button size="lg" className="gap-1">
                  Contact Us
                  <ArrowRight className="h-4 w-4" />
                </Button>
              </Link>
              <Link href="/apply">
                <Button size="lg" variant="outline">
                  Apply for a Loan
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

