import Link from "next/link"
import type { Metadata } from "next"
import { CreditCard } from "lucide-react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { RegisterForm } from "@/components/register-form"

// Update the metadata
export const metadata: Metadata = {
  title: "Register | DigiLoan",
  description: "Create a new DigiLoan account",
}

export default function RegisterPage() {
  return (
    <div className="flex min-h-screen items-center justify-center px-4 py-12">
      <Card className="w-full max-w-md">
        <CardHeader className="space-y-1">
          <div className="flex justify-center mb-4">
            {/* Update the logo and name */}
            <Link href="/" className="flex items-center gap-2">
              <div className="rounded-md bg-primary p-1">
                <CreditCard className="h-6 w-6 text-primary-foreground" />
              </div>
              <span className="text-xl font-bold">DigiLoan</span>
            </Link>
          </div>
          <CardTitle className="text-2xl text-center">Create an account</CardTitle>
          <CardDescription className="text-center">Enter your information to create your account</CardDescription>
        </CardHeader>
        <CardContent>
          <RegisterForm />
        </CardContent>
        <CardFooter className="flex justify-center">
          <div className="text-center text-sm text-muted-foreground">
            Already have an account?{" "}
            <Link href="/login" className="underline underline-offset-4 hover:text-primary">
              Log in
            </Link>
          </div>
        </CardFooter>
      </Card>
    </div>
  )
}

