import type { Metadata } from "next"
import { ArrowRight, CheckCircle, Shield } from "lucide-react"
import Link from "next/link"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { EligibilityChecker } from "@/components/eligibility-checker"

export const metadata: Metadata = {
  title: "Check Eligibility | DigiLoan",
  description: "Find out which loans you qualify for with our automated eligibility checker",
}

export default function EligibilityPage() {
  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="bg-gradient-to-b from-muted/50 to-background py-16 md:py-24">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center text-center space-y-4">
            <div className="space-y-2">
              <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">
                Check Your Loan Eligibility
              </h1>
              <p className="mx-auto max-w-[700px] text-muted-foreground md:text-xl">
                Find out which loans you qualify for in seconds with our automated eligibility checker
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Eligibility Checker Section */}
      <section className="py-12 md:py-20">
        <div className="container px-4 md:px-6">
          <div className="grid gap-8 lg:grid-cols-2">
            <div className="space-y-6">
              <h2 className="text-2xl font-bold tracking-tighter sm:text-3xl">How It Works</h2>
              <p className="text-muted-foreground">
                Our automated eligibility checker uses advanced algorithms to instantly assess your loan eligibility
                based on the information you provide. The process is quick, secure, and doesn't affect your credit
                score.
              </p>

              <div className="space-y-4">
                <div className="flex items-start gap-4">
                  <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary">
                    1
                  </div>
                  <div>
                    <h3 className="font-medium">Enter Your Information</h3>
                    <p className="text-sm text-muted-foreground">
                      Provide basic details about your loan needs, income, and credit profile.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary">
                    2
                  </div>
                  <div>
                    <h3 className="font-medium">Instant Assessment</h3>
                    <p className="text-sm text-muted-foreground">
                      Our system instantly analyzes your information against our lending criteria.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary">
                    3
                  </div>
                  <div>
                    <h3 className="font-medium">View Your Results</h3>
                    <p className="text-sm text-muted-foreground">
                      See which loans you qualify for, maximum amounts, and estimated rates.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary">
                    4
                  </div>
                  <div>
                    <h3 className="font-medium">Apply with Confidence</h3>
                    <p className="text-sm text-muted-foreground">
                      Proceed with your application knowing you're pre-qualified.
                    </p>
                  </div>
                </div>
              </div>

              <Card className="bg-muted/30">
                <CardContent className="p-4 flex items-start gap-4">
                  <Shield className="h-6 w-6 text-primary mt-1" />
                  <div>
                    <h3 className="font-medium">Automated Compliance Management</h3>
                    <p className="text-sm text-muted-foreground mt-1">
                      Our eligibility checker incorporates automated compliance checks to ensure all applications meet
                      regulatory requirements. This includes KYC verification, AML screening, and adherence to lending
                      regulations.
                    </p>
                  </div>
                </CardContent>
              </Card>

              <div className="rounded-lg border p-4">
                <h3 className="font-medium mb-2 flex items-center gap-2">
                  <CheckCircle className="h-5 w-5 text-green-500" />
                  <span>Benefits of Pre-Checking</span>
                </h3>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-start">
                    <span className="mr-2 font-bold">•</span>
                    <span>No impact on your credit score</span>
                  </li>
                  <li className="flex items-start">
                    <span className="mr-2 font-bold">•</span>
                    <span>Save time by applying only for loans you're likely to be approved for</span>
                  </li>
                  <li className="flex items-start">
                    <span className="mr-2 font-bold">•</span>
                    <span>Get personalized loan recommendations based on your profile</span>
                  </li>
                  <li className="flex items-start">
                    <span className="mr-2 font-bold">•</span>
                    <span>Understand your borrowing capacity before applying</span>
                  </li>
                </ul>
              </div>
            </div>

            <div>
              <EligibilityChecker />
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-muted py-12 md:py-16">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center gap-4 text-center">
            <h2 className="text-2xl font-bold tracking-tighter sm:text-3xl">Ready to Apply?</h2>
            <p className="max-w-[700px] text-muted-foreground">
              Once you've checked your eligibility, you can proceed with your loan application.
            </p>
            <div className="flex flex-col gap-2 min-[400px]:flex-row">
              <Link href="/apply">
                <Button size="lg" className="gap-1">
                  Apply Now
                  <ArrowRight className="h-4 w-4" />
                </Button>
              </Link>
              <Link href="/loans">
                <Button size="lg" variant="outline">
                  Explore Loan Types
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

