import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { DashboardHeader } from "@/components/dashboard-header"
import { LoanApplicationForm } from "@/components/loan-application-form"

export default function ApplyPage() {
  return (
    <div className="flex flex-col">
      <DashboardHeader heading="Loan Application" text="Apply for a new loan by filling out the form below." />

      <main className="flex-1 space-y-4 p-4 md:p-8 pt-6">
        <Tabs defaultValue="personal" className="space-y-4">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="personal">Personal Loan</TabsTrigger>
            <TabsTrigger value="auto">Auto Loan</TabsTrigger>
            <TabsTrigger value="home">Home Improvement</TabsTrigger>
          </TabsList>
          <TabsContent value="personal">
            <Card>
              <CardHeader>
                <CardTitle>Personal Loan Application</CardTitle>
                <CardDescription>Apply for a personal loan with competitive rates and flexible terms.</CardDescription>
              </CardHeader>
              <CardContent>
                <LoanApplicationForm loanType="personal" />
              </CardContent>
            </Card>
          </TabsContent>
          <TabsContent value="auto">
            <Card>
              <CardHeader>
                <CardTitle>Auto Loan Application</CardTitle>
                <CardDescription>Finance your new or used vehicle with our competitive auto loans.</CardDescription>
              </CardHeader>
              <CardContent>
                <LoanApplicationForm loanType="auto" />
              </CardContent>
            </Card>
          </TabsContent>
          <TabsContent value="home">
            <Card>
              <CardHeader>
                <CardTitle>Home Improvement Loan Application</CardTitle>
                <CardDescription>Get the funds you need for your home renovation projects.</CardDescription>
              </CardHeader>
              <CardContent>
                <LoanApplicationForm loanType="home" />
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}

