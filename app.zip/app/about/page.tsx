import type { Metadata } from "next"
import Image from "next/image"
import Link from "next/link"
import { ArrowRight, Award, Building, CheckCircle, Clock, CreditCard, Heart, Shield, Star, Users } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export const metadata: Metadata = {
  title: "About Us | LoanEase",
  description: "Learn about LoanEase, our mission, values, and the team behind our innovative loan platform.",
}

export default function AboutPage() {
  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="bg-gradient-to-b from-muted/50 to-background py-20 md:py-32">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center text-center space-y-4">
            <div className="space-y-2">
              <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl lg:text-6xl">
                About LoanEase
              </h1>
              <p className="mx-auto max-w-[700px] text-muted-foreground md:text-xl">
                We're on a mission to make loans accessible, transparent, and stress-free for everyone.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="py-12 md:py-20">
        <div className="container px-4 md:px-6">
          <div className="grid gap-6 lg:grid-cols-2 lg:gap-12 items-center">
            <div className="space-y-4">
              <div className="inline-block rounded-lg bg-primary/10 px-3 py-1 text-sm">Our Mission</div>
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl">
                Making Financial Freedom Accessible to All
              </h2>
              <p className="text-muted-foreground md:text-lg">
                At LoanEase, we believe that everyone deserves access to fair and transparent financial services. Our
                mission is to simplify the loan process, eliminate unnecessary barriers, and empower individuals to
                achieve their financial goals.
              </p>
              <p className="text-muted-foreground md:text-lg">
                We're committed to providing personalized loan solutions that meet the unique needs of each customer,
                backed by cutting-edge technology and exceptional customer service.
              </p>
            </div>
            <div className="flex justify-center">
              <div className="relative h-[400px] w-full max-w-[500px] overflow-hidden rounded-lg">
                <Image
                  src="/placeholder.svg?height=800&width=1000"
                  alt="Team collaborating"
                  fill
                  className="object-cover"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Our Values */}
      <section className="bg-muted py-12 md:py-20">
        <div className="container px-4 md:px-6">
          <div className="mx-auto flex max-w-[58rem] flex-col items-center justify-center gap-4 text-center">
            <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Our Core Values</h2>
            <p className="max-w-[85%] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
              These principles guide everything we do at LoanEase
            </p>
          </div>
          <div className="mx-auto grid max-w-5xl grid-cols-1 gap-6 py-12 md:grid-cols-3">
            <Card>
              <CardContent className="pt-6">
                <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                  <Shield className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-xl font-bold">Trust & Transparency</h3>
                <p className="mt-2 text-muted-foreground">
                  We believe in complete transparency with our customers. No hidden fees, no confusing terms—just
                  straightforward, honest service.
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                  <Heart className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-xl font-bold">Customer First</h3>
                <p className="mt-2 text-muted-foreground">
                  Our customers are at the heart of everything we do. We're committed to providing exceptional service
                  and support at every step.
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                  <CheckCircle className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-xl font-bold">Innovation</h3>
                <p className="mt-2 text-muted-foreground">
                  We continuously innovate to make the loan process faster, simpler, and more accessible through
                  cutting-edge technology.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Our Story */}
      <section className="py-12 md:py-20">
        <div className="container px-4 md:px-6">
          <div className="mx-auto max-w-3xl space-y-4 text-center">
            <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl">Our Story</h2>
            <p className="text-muted-foreground md:text-lg">
              LoanEase was founded in 2020 by a team of financial experts and technology innovators who saw a
              fundamental problem in the traditional lending industry: it was too complex, too slow, and often unfair to
              consumers.
            </p>
            <p className="text-muted-foreground md:text-lg">
              Our founders had witnessed firsthand how difficult it could be for qualified borrowers to access fair
              loans due to outdated processes and opaque terms. They set out to create a platform that would
              revolutionize the lending experience through technology, transparency, and a genuine commitment to
              customer success.
            </p>
            <p className="text-muted-foreground md:text-lg">
              Since our launch, we've helped thousands of customers secure loans for personal needs, auto purchases, and
              home improvements. We've grown from a small startup to a trusted financial partner, all while maintaining
              our core commitment to making loans accessible and stress-free.
            </p>
          </div>

          <div className="mt-12 flex justify-center">
            <Tabs defaultValue="milestones" className="w-full max-w-3xl">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="milestones">Milestones</TabsTrigger>
                <TabsTrigger value="growth">Growth</TabsTrigger>
                <TabsTrigger value="future">Future Vision</TabsTrigger>
              </TabsList>
              <TabsContent value="milestones" className="space-y-4 pt-4">
                <div className="space-y-4">
                  <div className="flex gap-4">
                    <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary">
                      2020
                    </div>
                    <div>
                      <h3 className="font-medium">Company Founded</h3>
                      <p className="text-sm text-muted-foreground">
                        LoanEase was established with a mission to transform the lending industry.
                      </p>
                    </div>
                  </div>
                  <div className="flex gap-4">
                    <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary">
                      2021
                    </div>
                    <div>
                      <h3 className="font-medium">Platform Launch</h3>
                      <p className="text-sm text-muted-foreground">
                        Our digital platform launched, offering personal loans with a streamlined application process.
                      </p>
                    </div>
                  </div>
                  <div className="flex gap-4">
                    <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary">
                      2022
                    </div>
                    <div>
                      <h3 className="font-medium">Expanded Loan Products</h3>
                      <p className="text-sm text-muted-foreground">
                        Added auto loans and home improvement financing to our product offerings.
                      </p>
                    </div>
                  </div>
                  <div className="flex gap-4">
                    <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary">
                      2023
                    </div>
                    <div>
                      <h3 className="font-medium">10,000 Customers Milestone</h3>
                      <p className="text-sm text-muted-foreground">
                        Celebrated helping our 10,000th customer achieve their financial goals.
                      </p>
                    </div>
                  </div>
                  <div className="flex gap-4">
                    <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary">
                      2024
                    </div>
                    <div>
                      <h3 className="font-medium">Industry Recognition</h3>
                      <p className="text-sm text-muted-foreground">
                        Received "Best Fintech Innovation" award and expanded to nationwide coverage.
                      </p>
                    </div>
                  </div>
                </div>
              </TabsContent>
              <TabsContent value="growth" className="space-y-4 pt-4">
                <div className="rounded-lg border p-4">
                  <h3 className="font-medium mb-2">Rapid Expansion</h3>
                  <p className="text-sm text-muted-foreground mb-4">
                    Since our founding, LoanEase has experienced remarkable growth:
                  </p>
                  <ul className="space-y-2 text-sm">
                    <li className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-primary" />
                      <span>500% year-over-year growth in loan originations</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-primary" />
                      <span>Expanded from 5 to 150 employees</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-primary" />
                      <span>Opened offices in 5 major cities across the country</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-primary" />
                      <span>Partnered with over 20 financial institutions</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-primary" />
                      <span>Achieved 95% customer satisfaction rating</span>
                    </li>
                  </ul>
                </div>
              </TabsContent>
              <TabsContent value="future" className="space-y-4 pt-4">
                <div className="rounded-lg border p-4">
                  <h3 className="font-medium mb-2">Looking Ahead</h3>
                  <p className="text-sm text-muted-foreground mb-4">Our vision for the future of LoanEase includes:</p>
                  <ul className="space-y-2 text-sm">
                    <li className="flex items-center gap-2">
                      <ArrowRight className="h-4 w-4 text-primary" />
                      <span>Expanding our product offerings to include business loans and mortgages</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <ArrowRight className="h-4 w-4 text-primary" />
                      <span>Implementing AI-powered loan recommendations for personalized financing</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <ArrowRight className="h-4 w-4 text-primary" />
                      <span>Launching financial education initiatives to empower borrowers</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <ArrowRight className="h-4 w-4 text-primary" />
                      <span>International expansion to bring our services to global markets</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <ArrowRight className="h-4 w-4 text-primary" />
                      <span>Continued innovation in making loans more accessible and affordable</span>
                    </li>
                  </ul>
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </section>

      {/* Leadership Team */}
      <section className="bg-muted py-12 md:py-20">
        <div className="container px-4 md:px-6">
          <div className="mx-auto flex max-w-[58rem] flex-col items-center justify-center gap-4 text-center">
            <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl">Meet Our Leadership</h2>
            <p className="max-w-[85%] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
              The experienced team guiding LoanEase's mission
            </p>
          </div>
          <div className="mx-auto grid max-w-5xl grid-cols-1 gap-8 py-12 md:grid-cols-3">
            <div className="flex flex-col items-center text-center">
              <div className="relative h-40 w-40 overflow-hidden rounded-full">
                <Image src="/placeholder.svg?height=160&width=160" alt="Sarah Johnson" fill className="object-cover" />
              </div>
              <h3 className="mt-4 text-xl font-bold">Sarah Johnson</h3>
              <p className="text-sm text-primary">Chief Executive Officer</p>
              <p className="mt-2 text-sm text-muted-foreground">
                Former VP at Capital Finance with 15+ years of experience in the financial services industry.
              </p>
            </div>
            <div className="flex flex-col items-center text-center">
              <div className="relative h-40 w-40 overflow-hidden rounded-full">
                <Image src="/placeholder.svg?height=160&width=160" alt="Michael Chen" fill className="object-cover" />
              </div>
              <h3 className="mt-4 text-xl font-bold">Michael Chen</h3>
              <p className="text-sm text-primary">Chief Technology Officer</p>
              <p className="mt-2 text-sm text-muted-foreground">
                Tech innovator with previous experience at leading fintech companies and a passion for user-centered
                design.
              </p>
            </div>
            <div className="flex flex-col items-center text-center">
              <div className="relative h-40 w-40 overflow-hidden rounded-full">
                <Image
                  src="/placeholder.svg?height=160&width=160"
                  alt="David Rodriguez"
                  fill
                  className="object-cover"
                />
              </div>
              <h3 className="mt-4 text-xl font-bold">David Rodriguez</h3>
              <p className="text-sm text-primary">Chief Financial Officer</p>
              <p className="mt-2 text-sm text-muted-foreground">
                Financial strategist with extensive experience in risk management and sustainable growth planning.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-12 md:py-20">
        <div className="container px-4 md:px-6">
          <div className="mx-auto flex max-w-[58rem] flex-col items-center justify-center gap-4 text-center">
            <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl">What Our Customers Say</h2>
            <p className="max-w-[85%] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
              Don't just take our word for it—hear from people who've experienced LoanEase
            </p>
          </div>
          <div className="mx-auto grid max-w-5xl grid-cols-1 gap-6 py-12 md:grid-cols-3">
            <Card>
              <CardContent className="pt-6">
                <div className="mb-4 flex items-center gap-4">
                  <div className="relative h-10 w-10 overflow-hidden rounded-full">
                    <Image src="/placeholder.svg?height=40&width=40" alt="Customer" fill className="object-cover" />
                  </div>
                  <div>
                    <p className="font-medium">Jennifer T.</p>
                    <p className="text-xs text-muted-foreground">Personal Loan Customer</p>
                  </div>
                </div>
                <div className="flex mb-2">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="h-4 w-4 fill-primary text-primary" />
                  ))}
                </div>
                <p className="text-sm text-muted-foreground">
                  "The entire process was incredibly smooth. I applied for a personal loan on a Monday and had the funds
                  by Wednesday. The rates were better than any other lender I found, and the customer service was
                  exceptional."
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <div className="mb-4 flex items-center gap-4">
                  <div className="relative h-10 w-10 overflow-hidden rounded-full">
                    <Image src="/placeholder.svg?height=40&width=40" alt="Customer" fill className="object-cover" />
                  </div>
                  <div>
                    <p className="font-medium">Marcus W.</p>
                    <p className="text-xs text-muted-foreground">Auto Loan Customer</p>
                  </div>
                </div>
                <div className="flex mb-2">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="h-4 w-4 fill-primary text-primary" />
                  ))}
                </div>
                <p className="text-sm text-muted-foreground">
                  "I was hesitant about applying for an auto loan online, but LoanEase made it so easy. Their calculator
                  helped me understand exactly what I could afford, and their team was there to answer all my
                  questions."
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <div className="mb-4 flex items-center gap-4">
                  <div className="relative h-10 w-10 overflow-hidden rounded-full">
                    <Image src="/placeholder.svg?height=40&width=40" alt="Customer" fill className="object-cover" />
                  </div>
                  <div>
                    <p className="font-medium">Sophia L.</p>
                    <p className="text-xs text-muted-foreground">Home Improvement Loan</p>
                  </div>
                </div>
                <div className="flex mb-2">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="h-4 w-4 fill-primary text-primary" />
                  ))}
                </div>
                <p className="text-sm text-muted-foreground">
                  "LoanEase helped me finance my kitchen renovation with a great rate and flexible terms. The dashboard
                  makes it easy to track my payments, and I love how transparent they are about everything."
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Credentials & Partners */}
      <section className="bg-muted py-12 md:py-20">
        <div className="container px-4 md:px-6">
          <div className="mx-auto flex max-w-[58rem] flex-col items-center justify-center gap-4 text-center">
            <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl">Our Credentials</h2>
            <p className="max-w-[85%] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
              Licensed, certified, and trusted by industry leaders
            </p>
          </div>
          <div className="mx-auto grid max-w-5xl grid-cols-1 gap-6 py-12 md:grid-cols-2">
            <div className="space-y-4">
              <h3 className="text-xl font-bold">Certifications & Licenses</h3>
              <ul className="space-y-2">
                <li className="flex items-center gap-2">
                  <Award className="h-5 w-5 text-primary" />
                  <span>Licensed in all 50 states</span>
                </li>
                <li className="flex items-center gap-2">
                  <Award className="h-5 w-5 text-primary" />
                  <span>NMLS Certified (ID: #12345678)</span>
                </li>
                <li className="flex items-center gap-2">
                  <Award className="h-5 w-5 text-primary" />
                  <span>SOC 2 Type II Compliant</span>
                </li>
                <li className="flex items-center gap-2">
                  <Award className="h-5 w-5 text-primary" />
                  <span>PCI DSS Certified</span>
                </li>
                <li className="flex items-center gap-2">
                  <Award className="h-5 w-5 text-primary" />
                  <span>A+ Rating with Better Business Bureau</span>
                </li>
              </ul>
            </div>
            <div className="space-y-4">
              <h3 className="text-xl font-bold">Our Partners</h3>
              <ul className="space-y-2">
                <li className="flex items-center gap-2">
                  <Building className="h-5 w-5 text-primary" />
                  <span>National Banking Association</span>
                </li>
                <li className="flex items-center gap-2">
                  <Building className="h-5 w-5 text-primary" />
                  <span>Financial Technology Alliance</span>
                </li>
                <li className="flex items-center gap-2">
                  <Building className="h-5 w-5 text-primary" />
                  <span>Consumer Financial Protection Network</span>
                </li>
                <li className="flex items-center gap-2">
                  <Building className="h-5 w-5 text-primary" />
                  <span>Digital Finance Consortium</span>
                </li>
                <li className="flex items-center gap-2">
                  <Building className="h-5 w-5 text-primary" />
                  <span>Responsible Lending Initiative</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-12 md:py-20">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center gap-4 text-center">
            <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">
              Ready to Experience the LoanEase Difference?
            </h2>
            <p className="max-w-[700px] text-muted-foreground md:text-xl/relaxed">
              Join thousands of satisfied customers who have found the perfect loan solution with us.
            </p>
            <div className="flex flex-col gap-2 min-[400px]:flex-row">
              <Link href="/apply">
                <Button size="lg" className="gap-1">
                  Apply Now
                  <ArrowRight className="h-4 w-4" />
                </Button>
              </Link>
              <Link href="/contact">
                <Button size="lg" variant="outline">
                  Contact Us
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Company Stats */}
      <section className="bg-muted py-12 md:py-20">
        <div className="container px-4 md:px-6">
          <div className="grid gap-6 md:grid-cols-4">
            <div className="flex flex-col items-center justify-center space-y-2 text-center">
              <div className="flex h-16 w-16 items-center justify-center rounded-full bg-primary/10">
                <Users className="h-8 w-8 text-primary" />
              </div>
              <div className="space-y-1">
                <h3 className="text-3xl font-bold">25,000+</h3>
                <p className="text-sm text-muted-foreground">Satisfied Customers</p>
              </div>
            </div>
            <div className="flex flex-col items-center justify-center space-y-2 text-center">
              <div className="flex h-16 w-16 items-center justify-center rounded-full bg-primary/10">
                <CreditCard className="h-8 w-8 text-primary" />
              </div>
              <div className="space-y-1">
                <h3 className="text-3xl font-bold">$250M+</h3>
                <p className="text-sm text-muted-foreground">Loans Funded</p>
              </div>
            </div>
            <div className="flex flex-col items-center justify-center space-y-2 text-center">
              <div className="flex h-16 w-16 items-center justify-center rounded-full bg-primary/10">
                <Clock className="h-8 w-8 text-primary" />
              </div>
              <div className="space-y-1">
                <h3 className="text-3xl font-bold">24 Hours</h3>
                <p className="text-sm text-muted-foreground">Average Approval Time</p>
              </div>
            </div>
            <div className="flex flex-col items-center justify-center space-y-2 text-center">
              <div className="flex h-16 w-16 items-center justify-center rounded-full bg-primary/10">
                <Star className="h-8 w-8 text-primary" />
              </div>
              <div className="space-y-1">
                <h3 className="text-3xl font-bold">4.9/5</h3>
                <p className="text-sm text-muted-foreground">Customer Rating</p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

