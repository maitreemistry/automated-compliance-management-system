import type { Metadata } from "next"
import Link from "next/link"
import { ArrowRight, Briefcase, Building, CreditCard, Home, Receipt, ShoppingBag, Users, Wallet } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export const metadata: Metadata = {
  title: "Loan Types | DigiLoan",
  description: "Explore our range of digital loan products for personal and business needs",
}

export default function LoansPage() {
  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="bg-gradient-to-b from-muted/50 to-background py-16 md:py-24">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center text-center space-y-4">
            <div className="space-y-2">
              <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Loan Products</h1>
              <p className="mx-auto max-w-[700px] text-muted-foreground md:text-xl">
                Discover our range of digital lending solutions tailored to your needs
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Loan Types Section */}
      <section className="py-12 md:py-20">
        <div className="container px-4 md:px-6">
          <Tabs defaultValue="personal" className="space-y-8">
            <div className="flex justify-center">
              <TabsList className="grid grid-cols-2 md:grid-cols-4 w-full max-w-3xl">
                <TabsTrigger value="personal">Personal</TabsTrigger>
                <TabsTrigger value="business">Business</TabsTrigger>
                <TabsTrigger value="specialized">Specialized</TabsTrigger>
                <TabsTrigger value="digital">Digital</TabsTrigger>
              </TabsList>
            </div>

            {/* Personal Loans Tab */}
            <TabsContent value="personal" className="space-y-8">
              <div className="grid gap-6 md:grid-cols-2">
                <Card>
                  <CardHeader>
                    <div className="mb-2 flex h-10 w-10 items-center justify-center rounded-full bg-primary/10">
                      <CreditCard className="h-5 w-5 text-primary" />
                    </div>
                    <CardTitle>Personal Loans</CardTitle>
                    <CardDescription>
                      Unsecured loans for individual borrowers for various personal expenses
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div>
                        <h3 className="font-medium">Features</h3>
                        <ul className="mt-2 space-y-2 text-sm">
                          <li className="flex items-start">
                            <span className="mr-2">•</span>
                            <span>Flexible repayment terms from 12 to 60 months</span>
                          </li>
                          <li className="flex items-start">
                            <span className="mr-2">•</span>
                            <span>Quick approval process, often within 24 hours</span>
                          </li>
                          <li className="flex items-start">
                            <span className="mr-2">•</span>
                            <span>Loan amounts from $1,000 to $50,000</span>
                          </li>
                          <li className="flex items-start">
                            <span className="mr-2">•</span>
                            <span>Competitive interest rates based on credit profile</span>
                          </li>
                        </ul>
                      </div>
                      <Link href="/apply?type=personal">
                        <Button className="w-full">Apply Now</Button>
                      </Link>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <div className="mb-2 flex h-10 w-10 items-center justify-center rounded-full bg-primary/10">
                      <Users className="h-5 w-5 text-primary" />
                    </div>
                    <CardTitle>Peer-to-Peer (P2P) Loans</CardTitle>
                    <CardDescription>
                      Connects individual borrowers directly with investors, bypassing traditional banks
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div>
                        <h3 className="font-medium">Features</h3>
                        <ul className="mt-2 space-y-2 text-sm">
                          <li className="flex items-start">
                            <span className="mr-2">•</span>
                            <span>Competitive interest rates compared to traditional loans</span>
                          </li>
                          <li className="flex items-start">
                            <span className="mr-2">•</span>
                            <span>Personalized loan terms based on your profile</span>
                          </li>
                          <li className="flex items-start">
                            <span className="mr-2">•</span>
                            <span>Transparent fee structure with no hidden charges</span>
                          </li>
                          <li className="flex items-start">
                            <span className="mr-2">•</span>
                            <span>Access to a diverse pool of investors</span>
                          </li>
                        </ul>
                      </div>
                      <Link href="/apply?type=p2p">
                        <Button className="w-full">Apply Now</Button>
                      </Link>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            {/* Business Loans Tab */}
            <TabsContent value="business" className="space-y-8">
              <div className="grid gap-6 md:grid-cols-3">
                <Card>
                  <CardHeader>
                    <div className="mb-2 flex h-10 w-10 items-center justify-center rounded-full bg-primary/10">
                      <Briefcase className="h-5 w-5 text-primary" />
                    </div>
                    <CardTitle>Business Loans</CardTitle>
                    <CardDescription>
                      Loans tailored for small and medium enterprises (SMEs) to support business growth
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div>
                        <h3 className="font-medium">Features</h3>
                        <ul className="mt-2 space-y-2 text-sm">
                          <li className="flex items-start">
                            <span className="mr-2">•</span>
                            <span>Options for working capital financing</span>
                          </li>
                          <li className="flex items-start">
                            <span className="mr-2">•</span>
                            <span>Equipment financing solutions</span>
                          </li>
                          <li className="flex items-start">
                            <span className="mr-2">•</span>
                            <span>Expansion funding for growing businesses</span>
                          </li>
                        </ul>
                      </div>
                      <Link href="/apply?type=business">
                        <Button className="w-full">Apply Now</Button>
                      </Link>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <div className="mb-2 flex h-10 w-10 items-center justify-center rounded-full bg-primary/10">
                      <Receipt className="h-5 w-5 text-primary" />
                    </div>
                    <CardTitle>Invoice Financing</CardTitle>
                    <CardDescription>
                      Short-term loans based on outstanding invoices to improve cash flow for businesses
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div>
                        <h3 className="font-medium">Features</h3>
                        <ul className="mt-2 space-y-2 text-sm">
                          <li className="flex items-start">
                            <span className="mr-2">•</span>
                            <span>Quick access to funds against unpaid invoices</span>
                          </li>
                          <li className="flex items-start">
                            <span className="mr-2">•</span>
                            <span>Advance rates up to 90% of invoice value</span>
                          </li>
                          <li className="flex items-start">
                            <span className="mr-2">•</span>
                            <span>No collateral required beyond the invoices</span>
                          </li>
                        </ul>
                      </div>
                      <Link href="/apply?type=invoice">
                        <Button className="w-full">Apply Now</Button>
                      </Link>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <div className="mb-2 flex h-10 w-10 items-center justify-center rounded-full bg-primary/10">
                      <Building className="h-5 w-5 text-primary" />
                    </div>
                    <CardTitle>Supply Chain Financing</CardTitle>
                    <CardDescription>
                      Financing options for businesses within a supply chain to manage cash flow effectively
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div>
                        <h3 className="font-medium">Features</h3>
                        <ul className="mt-2 space-y-2 text-sm">
                          <li className="flex items-start">
                            <span className="mr-2">•</span>
                            <span>Tailored solutions based on transaction history</span>
                          </li>
                          <li className="flex items-start">
                            <span className="mr-2">•</span>
                            <span>Financing based on supplier relationships</span>
                          </li>
                          <li className="flex items-start">
                            <span className="mr-2">•</span>
                            <span>Optimized payment terms for all parties</span>
                          </li>
                        </ul>
                      </div>
                      <Link href="/apply?type=supply-chain">
                        <Button className="w-full">Apply Now</Button>
                      </Link>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            {/* Specialized Loans Tab */}
            <TabsContent value="specialized" className="space-y-8">
              <div className="grid gap-6 md:grid-cols-2">
                <Card>
                  <CardHeader>
                    <div className="mb-2 flex h-10 w-10 items-center justify-center rounded-full bg-primary/10">
                      <Wallet className="h-5 w-5 text-primary" />
                    </div>
                    <CardTitle>Line of Credit</CardTitle>
                    <CardDescription>
                      A revolving credit facility allowing borrowers to withdraw funds as needed up to a limit
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div>
                        <h3 className="font-medium">Features</h3>
                        <ul className="mt-2 space-y-2 text-sm">
                          <li className="flex items-start">
                            <span className="mr-2">•</span>
                            <span>Flexibility in borrowing and repayment</span>
                          </li>
                          <li className="flex items-start">
                            <span className="mr-2">•</span>
                            <span>Pay interest only on the amount used</span>
                          </li>
                          <li className="flex items-start">
                            <span className="mr-2">•</span>
                            <span>Access funds whenever needed without reapplying</span>
                          </li>
                          <li className="flex items-start">
                            <span className="mr-2">•</span>
                            <span>Credit limits based on your financial profile</span>
                          </li>
                        </ul>
                      </div>
                      <Link href="/apply?type=line-of-credit">
                        <Button className="w-full">Apply Now</Button>
                      </Link>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <div className="mb-2 flex h-10 w-10 items-center justify-center rounded-full bg-primary/10">
                      <Home className="h-5 w-5 text-primary" />
                    </div>
                    <CardTitle>Digital Mortgages</CardTitle>
                    <CardDescription>
                      Fully online mortgage application process for home purchases or refinancing
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div>
                        <h3 className="font-medium">Features</h3>
                        <ul className="mt-2 space-y-2 text-sm">
                          <li className="flex items-start">
                            <span className="mr-2">•</span>
                            <span>Streamlined documentation and faster processing times</span>
                          </li>
                          <li className="flex items-start">
                            <span className="mr-2">•</span>
                            <span>Digital verification of income and assets</span>
                          </li>
                          <li className="flex items-start">
                            <span className="mr-2">•</span>
                            <span>Competitive interest rates with flexible terms</span>
                          </li>
                          <li className="flex items-start">
                            <span className="mr-2">•</span>
                            <span>Real-time application status updates</span>
                          </li>
                        </ul>
                      </div>
                      <Link href="/apply?type=mortgage">
                        <Button className="w-full">Apply Now</Button>
                      </Link>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            {/* Digital Loans Tab */}
            <TabsContent value="digital" className="space-y-8">
              <div className="grid gap-6 md:grid-cols-1">
                <Card>
                  <CardHeader>
                    <div className="mb-2 flex h-10 w-10 items-center justify-center rounded-full bg-primary/10">
                      <ShoppingBag className="h-5 w-5 text-primary" />
                    </div>
                    <CardTitle>Buy Now, Pay Later (BNPL)</CardTitle>
                    <CardDescription>
                      Allows consumers to make purchases and pay for them in installments over time
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div>
                        <h3 className="font-medium">Features</h3>
                        <ul className="mt-2 space-y-2 text-sm">
                          <li className="flex items-start">
                            <span className="mr-2">•</span>
                            <span>Instant credit approval at the point of sale</span>
                          </li>
                          <li className="flex items-start">
                            <span className="mr-2">•</span>
                            <span>No interest during the grace period</span>
                          </li>
                          <li className="flex items-start">
                            <span className="mr-2">•</span>
                            <span>Split payments into equal installments</span>
                          </li>
                          <li className="flex items-start">
                            <span className="mr-2">•</span>
                            <span>Seamless integration with online shopping platforms</span>
                          </li>
                          <li className="flex items-start">
                            <span className="mr-2">•</span>
                            <span>Transparent fee structure with no hidden charges</span>
                          </li>
                        </ul>
                      </div>
                      <Link href="/apply?type=bnpl">
                        <Button className="w-full">Apply Now</Button>
                      </Link>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </section>

      {/* Loan Application Process */}
      <section className="py-12 md:py-20 bg-muted/30">
        <div className="container px-4 md:px-6">
          <div className="mx-auto flex max-w-[58rem] flex-col items-center justify-center gap-4 text-center">
            <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl">Loan Application Process</h2>
            <p className="max-w-[85%] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
              Our streamlined digital process makes applying for loans quick and easy
            </p>
          </div>

          <div className="mx-auto grid max-w-5xl grid-cols-1 gap-8 py-12 md:grid-cols-4">
            <div className="flex flex-col items-center text-center space-y-2">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary text-primary-foreground">
                1
              </div>
              <h3 className="text-xl font-bold">Check Eligibility</h3>
              <p className="text-sm text-muted-foreground">
                Use our eligibility checker to see which loans you qualify for
              </p>
            </div>

            <div className="flex flex-col items-center text-center space-y-2">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary text-primary-foreground">
                2
              </div>
              <h3 className="text-xl font-bold">Complete Application</h3>
              <p className="text-sm text-muted-foreground">
                Fill out our simple online application form with your details
              </p>
            </div>

            <div className="flex flex-col items-center text-center space-y-2">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary text-primary-foreground">
                3
              </div>
              <h3 className="text-xl font-bold">Verification</h3>
              <p className="text-sm text-muted-foreground">
                Our automated system verifies your information and documents
              </p>
            </div>

            <div className="flex flex-col items-center text-center space-y-2">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary text-primary-foreground">
                4
              </div>
              <h3 className="text-xl font-bold">Receive Funds</h3>
              <p className="text-sm text-muted-foreground">
                Once approved, funds are disbursed directly to your account
              </p>
            </div>
          </div>

          <div className="flex justify-center">
            <Link href="/apply">
              <Button size="lg" className="gap-1">
                Start Application
                <ArrowRight className="h-4 w-4" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Compliance Information */}
      <section className="py-12 md:py-20">
        <div className="container px-4 md:px-6">
          <div className="mx-auto flex max-w-[58rem] flex-col items-center justify-center gap-4 text-center">
            <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl">Compliance Information</h2>
            <p className="max-w-[85%] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
              We adhere to the highest standards of regulatory compliance and data protection
            </p>
          </div>

          <div className="mx-auto grid max-w-5xl grid-cols-1 gap-8 py-12 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Regulatory Compliance</CardTitle>
                <CardDescription>How we comply with financial regulations</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <span className="mr-2 font-bold">•</span>
                    <span>KYC (Know Your Customer) verification for all applicants</span>
                  </li>
                  <li className="flex items-start">
                    <span className="mr-2 font-bold">•</span>
                    <span>AML (Anti-Money Laundering) monitoring and reporting</span>
                  </li>
                  <li className="flex items-start">
                    <span className="mr-2 font-bold">•</span>
                    <span>Compliance with lending regulations in all operating jurisdictions</span>
                  </li>
                  <li className="flex items-start">
                    <span className="mr-2 font-bold">•</span>
                    <span>Regular audits and reporting to regulatory authorities</span>
                  </li>
                  <li className="flex items-start">
                    <span className="mr-2 font-bold">•</span>
                    <span>Transparent fee structures and interest rate disclosures</span>
                  </li>
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Data Protection</CardTitle>
                <CardDescription>How we protect your personal information</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <span className="mr-2 font-bold">•</span>
                    <span>End-to-end encryption for all personal and financial data</span>
                  </li>
                  <li className="flex items-start">
                    <span className="mr-2 font-bold">•</span>
                    <span>Compliance with GDPR and other data protection regulations</span>
                  </li>
                  <li className="flex items-start">
                    <span className="mr-2 font-bold">•</span>
                    <span>Secure storage with limited access to authorized personnel only</span>
                  </li>
                  <li className="flex items-start">
                    <span className="mr-2 font-bold">•</span>
                    <span>Regular security audits and vulnerability assessments</span>
                  </li>
                  <li className="flex items-start">
                    <span className="mr-2 font-bold">•</span>
                    <span>Clear privacy policy outlining how your data is used</span>
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-muted py-12 md:py-20">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center gap-4 text-center">
            <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Ready to Get Started?</h2>
            <p className="max-w-[700px] text-muted-foreground md:text-xl/relaxed">
              Join thousands of satisfied customers who have found the perfect loan solution with DigiLoan.
            </p>
            <div className="flex flex-col gap-2 min-[400px]:flex-row">
              <Link href="/apply">
                <Button size="lg" className="gap-1">
                  Apply Now
                  <ArrowRight className="h-4 w-4" />
                </Button>
              </Link>
              <Link href="/eligibility">
                <Button size="lg" variant="outline">
                  Check Eligibility
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

