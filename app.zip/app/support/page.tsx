import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { DashboardHeader } from "@/components/dashboard-header"
import { SupportForm } from "@/components/support-form"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Badge } from "@/components/ui/badge"
import { MessageSquare, Phone, Mail } from "lucide-react"

export default function SupportPage() {
  return (
    <div className="flex flex-col">
      <DashboardHeader heading="Customer Support" text="Get help with your account and loans.">
        <Button size="sm" className="gap-1">
          <MessageSquare className="h-4 w-4" />
          <span className="hidden sm:inline">Live Chat</span>
        </Button>
      </DashboardHeader>

      <main className="flex-1 space-y-4 p-4 md:p-8 pt-6">
        <Tabs defaultValue="contact" className="space-y-4">
          <TabsList>
            <TabsTrigger value="contact">Contact Us</TabsTrigger>
            <TabsTrigger value="faq">FAQ</TabsTrigger>
            <TabsTrigger value="tickets">Support Tickets</TabsTrigger>
          </TabsList>

          <TabsContent value="contact">
            <div className="grid gap-4 md:grid-cols-7">
              <Card className="md:col-span-3">
                <CardHeader>
                  <CardTitle>Contact Support</CardTitle>
                  <CardDescription>Fill out the form and we'll get back to you as soon as possible</CardDescription>
                </CardHeader>
                <CardContent>
                  <SupportForm />
                </CardContent>
              </Card>

              <Card className="md:col-span-4">
                <CardHeader>
                  <CardTitle>Contact Information</CardTitle>
                  <CardDescription>Other ways to reach our support team</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    <div className="flex items-start gap-4">
                      <div className="rounded-full bg-primary/10 p-2">
                        <Phone className="h-5 w-5 text-primary" />
                      </div>
                      <div>
                        <h3 className="font-medium">Phone Support</h3>
                        <p className="text-sm text-muted-foreground mb-1">Available Monday-Friday, 8am-8pm ET</p>
                        <p className="text-sm font-medium">1-800-555-LOAN (5626)</p>
                      </div>
                    </div>

                    <div className="flex items-start gap-4">
                      <div className="rounded-full bg-primary/10 p-2">
                        <Mail className="h-5 w-5 text-primary" />
                      </div>
                      <div>
                        <h3 className="font-medium">Email Support</h3>
                        <p className="text-sm text-muted-foreground mb-1">We typically respond within 24 hours</p>
                        <p className="text-sm font-medium">support@loanease.com</p>
                      </div>
                    </div>

                    <div className="flex items-start gap-4">
                      <div className="rounded-full bg-primary/10 p-2">
                        <MessageSquare className="h-5 w-5 text-primary" />
                      </div>
                      <div>
                        <h3 className="font-medium">Live Chat</h3>
                        <p className="text-sm text-muted-foreground mb-1">Available 24/7 for immediate assistance</p>
                        <Button size="sm" variant="outline">
                          Start Chat
                        </Button>
                      </div>
                    </div>

                    <div className="rounded-lg border p-4 bg-muted/30 mt-6">
                      <h3 className="font-medium mb-2">Business Hours</h3>
                      <div className="grid grid-cols-2 gap-2 text-sm">
                        <div>Monday - Friday:</div>
                        <div>8:00 AM - 8:00 PM ET</div>
                        <div>Saturday:</div>
                        <div>9:00 AM - 5:00 PM ET</div>
                        <div>Sunday:</div>
                        <div>Closed (Chat support available)</div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="faq">
            <Card>
              <CardHeader>
                <CardTitle>Frequently Asked Questions</CardTitle>
                <CardDescription>Find answers to common questions about our services</CardDescription>
              </CardHeader>
              <CardContent>
                <Accordion type="single" collapsible className="w-full">
                  <AccordionItem value="item-1">
                    <AccordionTrigger>How do I apply for a loan?</AccordionTrigger>
                    <AccordionContent>
                      <p className="mb-2">You can apply for a loan in three simple steps:</p>
                      <ol className="list-decimal pl-5 space-y-1">
                        <li>Create an account or log in to your existing account</li>
                        <li>Navigate to the "Apply" section and select your desired loan type</li>
                        <li>Complete the application form with your personal and financial information</li>
                      </ol>
                      <p className="mt-2">
                        Once submitted, we'll review your application and provide a decision typically within 24-48
                        hours.
                      </p>
                    </AccordionContent>
                  </AccordionItem>

                  <AccordionItem value="item-2">
                    <AccordionTrigger>What documents do I need to apply?</AccordionTrigger>
                    <AccordionContent>
                      <p className="mb-2">To complete your loan application, you'll need to provide:</p>
                      <ul className="list-disc pl-5 space-y-1">
                        <li>Government-issued photo ID (driver's license, passport, etc.)</li>
                        <li>Proof of income (recent pay stubs, tax returns, or bank statements)</li>
                        <li>Proof of address (utility bill, lease agreement, etc.)</li>
                        <li>Social Security Number</li>
                        <li>Banking information for deposits and payments</li>
                      </ul>
                      <p className="mt-2">
                        Additional documents may be required depending on the loan type and amount.
                      </p>
                    </AccordionContent>
                  </AccordionItem>

                  <AccordionItem value="item-3">
                    <AccordionTrigger>How long does the approval process take?</AccordionTrigger>
                    <AccordionContent>
                      <p>
                        For most personal loans, you'll receive a decision within 24-48 hours after submitting a
                        complete application. Auto loans typically have a similar timeline. Once approved, funds are
                        usually disbursed within 1-3 business days, depending on your bank.
                      </p>
                    </AccordionContent>
                  </AccordionItem>

                  <AccordionItem value="item-4">
                    <AccordionTrigger>What are the interest rates and fees?</AccordionTrigger>
                    <AccordionContent>
                      <p className="mb-2">Our interest rates vary based on several factors:</p>
                      <ul className="list-disc pl-5 space-y-1">
                        <li>Loan type (personal, auto, home improvement)</li>
                        <li>Loan amount and term</li>
                        <li>Your credit score and history</li>
                        <li>Income and debt-to-income ratio</li>
                      </ul>
                      <p className="mt-2">
                        Current rates range from 5.99% to 18.99% APR. We pride ourselves on transparency with no hidden
                        fees. There may be an origination fee of 1-5% depending on your credit profile.
                      </p>
                    </AccordionContent>
                  </AccordionItem>

                  <AccordionItem value="item-5">
                    <AccordionTrigger>How do I make payments on my loan?</AccordionTrigger>
                    <AccordionContent>
                      <p className="mb-2">We offer several convenient payment methods:</p>
                      <ul className="list-disc pl-5 space-y-1">
                        <li>Online payments through your account dashboard</li>
                        <li>Automatic payments (set up in your account settings)</li>
                        <li>Phone payments by calling our customer service</li>
                        <li>Mail-in payments (details provided in your loan agreement)</li>
                      </ul>
                      <p className="mt-2">
                        We recommend setting up automatic payments to ensure you never miss a due date and to
                        potentially qualify for an interest rate discount.
                      </p>
                    </AccordionContent>
                  </AccordionItem>

                  <AccordionItem value="item-6">
                    <AccordionTrigger>Can I pay off my loan early?</AccordionTrigger>
                    <AccordionContent>
                      <p>
                        Yes, you can pay off your loan early without any prepayment penalties. Making extra payments or
                        paying off your loan before the end of the term can save you money on interest. You can make
                        additional payments at any time through your online account or by contacting customer service.
                      </p>
                    </AccordionContent>
                  </AccordionItem>
                </Accordion>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="tickets">
            <Card>
              <CardHeader>
                <CardTitle>Support Tickets</CardTitle>
                <CardDescription>View and manage your support requests</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="rounded-lg border">
                  <div className="grid grid-cols-1 md:grid-cols-5 p-4 text-sm font-medium">
                    <div>Ticket ID</div>
                    <div>Subject</div>
                    <div>Date</div>
                    <div>Status</div>
                    <div></div>
                  </div>
                  <div className="divide-y">
                    <div className="grid grid-cols-1 md:grid-cols-5 p-4 text-sm items-center">
                      <div>#12345</div>
                      <div>Payment Issue</div>
                      <div>Mar 18, 2025</div>
                      <div>
                        <Badge variant="outline" className="bg-amber-50 text-amber-700 border-amber-200">
                          In Progress
                        </Badge>
                      </div>
                      <div className="text-right">
                        <Button variant="ghost" size="sm">
                          View
                        </Button>
                      </div>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-5 p-4 text-sm items-center">
                      <div>#12289</div>
                      <div>Loan Application Question</div>
                      <div>Mar 10, 2025</div>
                      <div>
                        <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                          Resolved
                        </Badge>
                      </div>
                      <div className="text-right">
                        <Button variant="ghost" size="sm">
                          View
                        </Button>
                      </div>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-5 p-4 text-sm items-center">
                      <div>#11987</div>
                      <div>Account Access</div>
                      <div>Feb 28, 2025</div>
                      <div>
                        <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                          Resolved
                        </Badge>
                      </div>
                      <div className="text-right">
                        <Button variant="ghost" size="sm">
                          View
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="mt-6 flex justify-end">
                  <Button>Create New Ticket</Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}

