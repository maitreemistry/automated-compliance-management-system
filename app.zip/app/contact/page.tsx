import type { Metadata } from "next"
import { Mail, MapPin, Phone, Clock, Facebook, Twitter, Instagram, Linkedin } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { ContactForm } from "@/components/contact-form"

export const metadata: Metadata = {
  title: "Contact Us | DigiLoan",
  description: "Get in touch with our team for any questions or support",
}

export default function ContactPage() {
  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="bg-gradient-to-b from-muted/50 to-background py-16 md:py-24">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center text-center space-y-4">
            <div className="space-y-2">
              <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Contact Us</h1>
              <p className="mx-auto max-w-[700px] text-muted-foreground md:text-xl">
                We're here to help. Reach out to our team for support or inquiries.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-12 md:py-20">
        <div className="container px-4 md:px-6">
          <div className="grid gap-8 lg:grid-cols-2">
            <div className="space-y-6">
              <h2 className="text-2xl font-bold tracking-tighter sm:text-3xl">Get in Touch</h2>
              <p className="text-muted-foreground">
                Have questions about our loan products or need assistance with your application? Our team is ready to
                help you with any inquiries.
              </p>

              <div className="space-y-4">
                <Card>
                  <CardContent className="p-4 flex items-start gap-4">
                    <div className="rounded-full bg-primary/10 p-2 mt-1">
                      <Phone className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-medium">Phone Support</h3>
                      <p className="text-sm text-muted-foreground mb-1">Available Monday-Friday, 8am-8pm ET</p>
                      <p className="text-sm font-medium">1-800-555-LOAN (5626)</p>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-4 flex items-start gap-4">
                    <div className="rounded-full bg-primary/10 p-2 mt-1">
                      <Mail className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-medium">Email Support</h3>
                      <p className="text-sm text-muted-foreground mb-1">We typically respond within 24 hours</p>
                      <p className="text-sm font-medium">support@digiloan.com</p>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-4 flex items-start gap-4">
                    <div className="rounded-full bg-primary/10 p-2 mt-1">
                      <MapPin className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-medium">Office Location</h3>
                      <p className="text-sm text-muted-foreground mb-1">Visit our headquarters</p>
                      <p className="text-sm">
                        123 Financial Street, Suite 400
                        <br />
                        New York, NY 10001
                      </p>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-4 flex items-start gap-4">
                    <div className="rounded-full bg-primary/10 p-2 mt-1">
                      <Clock className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-medium">Business Hours</h3>
                      <div className="text-sm space-y-1 mt-1">
                        <div className="grid grid-cols-2 gap-2">
                          <span>Monday - Friday:</span>
                          <span>8:00 AM - 8:00 PM ET</span>
                          <span>Saturday:</span>
                          <span>9:00 AM - 5:00 PM ET</span>
                          <span>Sunday:</span>
                          <span>Closed</span>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <div className="pt-4">
                <h3 className="text-lg font-medium mb-3">Connect With Us</h3>
                <div className="flex space-x-4">
                  <a href="#" className="rounded-full bg-muted p-2 hover:bg-muted/80">
                    <Facebook className="h-5 w-5" />
                  </a>
                  <a href="#" className="rounded-full bg-muted p-2 hover:bg-muted/80">
                    <Twitter className="h-5 w-5" />
                  </a>
                  <a href="#" className="rounded-full bg-muted p-2 hover:bg-muted/80">
                    <Instagram className="h-5 w-5" />
                  </a>
                  <a href="#" className="rounded-full bg-muted p-2 hover:bg-muted/80">
                    <Linkedin className="h-5 w-5" />
                  </a>
                </div>
              </div>
            </div>

            <div className="space-y-6">
              <h2 className="text-2xl font-bold tracking-tighter sm:text-3xl">Send Us a Message</h2>
              <p className="text-muted-foreground">
                Fill out the form below and our team will get back to you as soon as possible.
              </p>
              <Card>
                <CardContent className="p-6">
                  <ContactForm />
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Map Section */}
      <section className="py-8 md:py-12 bg-muted/30">
        <div className="container px-4 md:px-6">
          <div className="mx-auto max-w-5xl">
            <div className="rounded-lg overflow-hidden border h-[400px] w-full">
              <div className="h-full w-full bg-muted flex items-center justify-center">
                <p className="text-muted-foreground">Interactive map would be displayed here</p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

