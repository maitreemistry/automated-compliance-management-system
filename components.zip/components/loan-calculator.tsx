"use client"

import { useState, useEffect } from "react"
import { Slider } from "@/components/ui/slider"
import { Label } from "@/components/ui/label"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { ArrowRight } from "lucide-react"
import Link from "next/link"

export function LoanCalculator() {
  const [loanAmount, setLoanAmount] = useState(10000)
  const [loanTerm, setLoanTerm] = useState(36)
  const [interestRate, setInterestRate] = useState(5.9)
  const [monthlyPayment, setMonthlyPayment] = useState(0)
  const [totalPayment, setTotalPayment] = useState(0)
  const [totalInterest, setTotalInterest] = useState(0)

  useEffect(() => {
    // Calculate monthly payment using the formula: P = L[i(1+i)^n]/[(1+i)^n-1]
    // Where P = monthly payment, L = loan amount, i = monthly interest rate, n = number of payments
    const monthlyInterestRate = interestRate / 100 / 12
    const numberOfPayments = loanTerm

    const monthlyPaymentValue =
      (loanAmount * monthlyInterestRate * Math.pow(1 + monthlyInterestRate, numberOfPayments)) /
      (Math.pow(1 + monthlyInterestRate, numberOfPayments) - 1)

    const totalPaymentValue = monthlyPaymentValue * numberOfPayments
    const totalInterestValue = totalPaymentValue - loanAmount

    setMonthlyPayment(isNaN(monthlyPaymentValue) ? 0 : monthlyPaymentValue)
    setTotalPayment(isNaN(totalPaymentValue) ? 0 : totalPaymentValue)
    setTotalInterest(isNaN(totalInterestValue) ? 0 : totalInterestValue)
  }, [loanAmount, loanTerm, interestRate])

  return (
    <div className="space-y-6">
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <Label htmlFor="loan-amount">Loan Amount</Label>
          <span className="text-sm font-medium">${loanAmount.toLocaleString()}</span>
        </div>
        <Slider
          id="loan-amount"
          min={1000}
          max={100000}
          step={1000}
          value={[loanAmount]}
          onValueChange={(value) => setLoanAmount(value[0])}
        />
        <div className="flex justify-between text-xs text-muted-foreground">
          <span>$1,000</span>
          <span>$100,000</span>
        </div>
      </div>

      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <Label htmlFor="loan-term">Loan Term (months)</Label>
          <span className="text-sm font-medium">{loanTerm} months</span>
        </div>
        <Slider
          id="loan-term"
          min={12}
          max={84}
          step={12}
          value={[loanTerm]}
          onValueChange={(value) => setLoanTerm(value[0])}
        />
        <div className="flex justify-between text-xs text-muted-foreground">
          <span>12 months</span>
          <span>84 months</span>
        </div>
      </div>

      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <Label htmlFor="interest-rate">Interest Rate</Label>
          <span className="text-sm font-medium">{interestRate}%</span>
        </div>
        <Slider
          id="interest-rate"
          min={1}
          max={20}
          step={0.1}
          value={[interestRate]}
          onValueChange={(value) => setInterestRate(value[0])}
        />
        <div className="flex justify-between text-xs text-muted-foreground">
          <span>1%</span>
          <span>20%</span>
        </div>
      </div>

      <Card className="bg-muted/50">
        <CardContent className="p-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1">
              <p className="text-xs text-muted-foreground">Monthly Payment</p>
              <p className="text-lg font-bold">${monthlyPayment.toFixed(2)}</p>
            </div>
            <div className="space-y-1">
              <p className="text-xs text-muted-foreground">Total Payment</p>
              <p className="text-lg font-bold">${totalPayment.toFixed(2)}</p>
            </div>
            <div className="space-y-1">
              <p className="text-xs text-muted-foreground">Total Interest</p>
              <p className="text-lg font-bold">${totalInterest.toFixed(2)}</p>
            </div>
            <div className="space-y-1">
              <p className="text-xs text-muted-foreground">Interest Rate</p>
              <p className="text-lg font-bold">{interestRate}%</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Link href="/apply" className="w-full">
        <Button className="w-full gap-2">
          Apply Now
          <ArrowRight className="h-4 w-4" />
        </Button>
      </Link>
    </div>
  )
}

