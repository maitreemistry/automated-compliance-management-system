"use client"

import { useState } from "react"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import { z } from "zod"
import { ArrowRight, Check, ChevronsUpDown, Loader2 } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Slider } from "@/components/ui/slider"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Checkbox } from "@/components/ui/checkbox"
import { Progress } from "@/components/ui/progress"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@/components/ui/command"
import { cn } from "@/lib/utils"
import { useToast } from "@/hooks/use-toast"
import { ComplianceMonitor } from "@/components/compliance-monitor"

const employmentStatuses = [
  { label: "Full-time", value: "full-time" },
  { label: "Part-time", value: "part-time" },
  { label: "Self-employed", value: "self-employed" },
  { label: "Unemployed", value: "unemployed" },
  { label: "Retired", value: "retired" },
  { label: "Student", value: "student" },
]

const purposes = {
  personal: [
    { label: "Debt Consolidation", value: "debt-consolidation" },
    { label: "Home Improvement", value: "home-improvement" },
    { label: "Major Purchase", value: "major-purchase" },
    { label: "Medical Expenses", value: "medical-expenses" },
    { label: "Education", value: "education" },
    { label: "Vacation", value: "vacation" },
    { label: "Other", value: "other" },
  ],
  auto: [
    { label: "New Vehicle Purchase", value: "new-vehicle" },
    { label: "Used Vehicle Purchase", value: "used-vehicle" },
    { label: "Refinance Existing Auto Loan", value: "refinance" },
  ],
  home: [
    { label: "Kitchen Renovation", value: "kitchen" },
    { label: "Bathroom Renovation", value: "bathroom" },
    { label: "Room Addition", value: "room-addition" },
    { label: "Roof Replacement", value: "roof" },
    { label: "HVAC System", value: "hvac" },
    { label: "Other Renovation", value: "other-renovation" },
  ],
}

const formSchema = z.object({
  loanAmount: z.number().min(1000, "Minimum loan amount is $1,000").max(100000, "Maximum loan amount is $100,000"),
  loanTerm: z.number().min(12, "Minimum term is 12 months").max(84, "Maximum term is 84 months"),
  purpose: z.string().min(1, "Please select a purpose for your loan"),
  firstName: z.string().min(2, "First name must be at least 2 characters"),
  lastName: z.string().min(2, "Last name must be at least 2 characters"),
  email: z.string().email("Please enter a valid email address"),
  phone: z.string().min(10, "Please enter a valid phone number"),
  address: z.string().min(5, "Please enter your full address"),
  city: z.string().min(2, "Please enter your city"),
  state: z.string().min(2, "Please enter your state"),
  zipCode: z.string().min(5, "Please enter a valid ZIP code"),
  employmentStatus: z.string().min(1, "Please select your employment status"),
  employerName: z.string().optional(),
  monthlyIncome: z.number().min(1, "Please enter your monthly income"),
  creditScore: z.enum(["excellent", "good", "fair", "poor"]),
  additionalInfo: z.string().optional(),
  agreeTerms: z.boolean().refine((val) => val === true, {
    message: "You must agree to the terms and conditions",
  }),
})

type FormValues = z.infer<typeof formSchema>

interface LoanApplicationFormProps {
  loanType: "personal" | "auto" | "home"
}

export function LoanApplicationForm({ loanType }: LoanApplicationFormProps) {
  const [step, setStep] = useState(1)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const { toast } = useToast()

  const [complianceStatus, setComplianceStatus] = useState({
    kycVerified: false,
    amlChecked: false,
    regulatoryCompliant: false,
    dataProtectionCompliant: true,
    overallCompliant: false,
    flags: [],
  })

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      loanAmount: 10000,
      loanTerm: 36,
      purpose: "",
      firstName: "",
      lastName: "",
      email: "",
      phone: "",
      address: "",
      city: "",
      state: "",
      zipCode: "",
      employmentStatus: "",
      employerName: "",
      monthlyIncome: 0,
      creditScore: "good",
      additionalInfo: "",
      agreeTerms: false,
    },
  })

  const totalSteps = 4
  const progress = (step / totalSteps) * 100

  function checkCompliance(data: any) {
    // Simulate automated compliance checks
    const newStatus = {
      kycVerified: !!data.firstName && !!data.lastName && !!data.email,
      amlChecked: true,
      regulatoryCompliant: true,
      dataProtectionCompliant: true,
      overallCompliant: false,
      flags: [] as string[],
    }

    // Add compliance flags if needed
    if (!data.firstName || !data.lastName) {
      newStatus.flags.push("KYC: Full name required")
    }

    if (data.loanAmount > 50000) {
      newStatus.flags.push("Regulatory: Enhanced due diligence required for loans over $50,000")
    }

    // Set overall compliance status
    newStatus.overallCompliant =
      newStatus.kycVerified &&
      newStatus.amlChecked &&
      newStatus.regulatoryCompliant &&
      newStatus.dataProtectionCompliant &&
      newStatus.flags.length === 0

    setComplianceStatus(newStatus)
    return newStatus.overallCompliant
  }

  function onSubmit(data: FormValues) {
    setIsSubmitting(true)

    // Perform automated compliance checks
    const isCompliant = checkCompliance(data)

    // If compliant, proceed with submission
    if (isCompliant) {
      // Simulate API call
      setTimeout(() => {
        console.log(data)
        setIsSubmitting(false)
        toast({
          title: "Application Submitted",
          description: "Your loan application has been submitted successfully.",
        })
      }, 2000)
    } else {
      // Handle compliance issues
      setIsSubmitting(false)
      toast({
        title: "Compliance Issues Detected",
        description: "Please review the compliance alerts and update your application.",
        variant: "destructive",
      })
    }
  }

  function nextStep() {
    const fieldsToValidate = {
      1: ["loanAmount", "loanTerm", "purpose"],
      2: ["firstName", "lastName", "email", "phone"],
      3: ["address", "city", "state", "zipCode", "employmentStatus", "monthlyIncome", "creditScore"],
    }[step] as Array<keyof FormValues>

    form.trigger(fieldsToValidate).then((isValid) => {
      if (isValid) {
        setStep(step + 1)
        window.scrollTo(0, 0)
      }
    })
  }

  function prevStep() {
    setStep(step - 1)
    window.scrollTo(0, 0)
  }

  return (
    <div className="space-y-6">
      <div className="space-y-2">
        <div className="flex justify-between text-sm">
          <span>
            Step {step} of {totalSteps}
          </span>
          <span>{Math.round(progress)}% Complete</span>
        </div>
        <Progress value={progress} className="h-2" />
      </div>

      {step === 1 && <ComplianceMonitor status={complianceStatus} className="mb-6" />}

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
          {step === 1 && (
            <div className="space-y-6">
              <h3 className="text-lg font-medium">Loan Details</h3>

              <FormField
                control={form.control}
                name="loanAmount"
                render={({ field }) => (
                  <FormItem className="space-y-4">
                    <div className="flex items-center justify-between">
                      <FormLabel>Loan Amount</FormLabel>
                      <span className="text-sm font-medium">${field.value.toLocaleString()}</span>
                    </div>
                    <FormControl>
                      <Slider
                        min={1000}
                        max={100000}
                        step={1000}
                        value={[field.value]}
                        onValueChange={(value) => field.onChange(value[0])}
                      />
                    </FormControl>
                    <div className="flex justify-between text-xs text-muted-foreground">
                      <span>$1,000</span>
                      <span>$100,000</span>
                    </div>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="loanTerm"
                render={({ field }) => (
                  <FormItem className="space-y-4">
                    <div className="flex items-center justify-between">
                      <FormLabel>Loan Term (months)</FormLabel>
                      <span className="text-sm font-medium">{field.value} months</span>
                    </div>
                    <FormControl>
                      <Slider
                        min={12}
                        max={84}
                        step={12}
                        value={[field.value]}
                        onValueChange={(value) => field.onChange(value[0])}
                      />
                    </FormControl>
                    <div className="flex justify-between text-xs text-muted-foreground">
                      <span>12 months</span>
                      <span>84 months</span>
                    </div>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="purpose"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Loan Purpose</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select a purpose for your loan" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {purposes[loanType].map((purpose) => (
                          <SelectItem key={purpose.value} value={purpose.value}>
                            {purpose.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <Card className="bg-muted/50">
                <CardContent className="p-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <p className="text-xs text-muted-foreground">Estimated Monthly Payment</p>
                      <p className="text-lg font-bold">
                        $
                        {(
                          (form.getValues("loanAmount") * (0.06 / 12)) /
                          (1 - Math.pow(1 + 0.06 / 12, -form.getValues("loanTerm")))
                        ).toFixed(2)}
                      </p>
                    </div>
                    <div className="space-y-1">
                      <p className="text-xs text-muted-foreground">Estimated Total Payment</p>
                      <p className="text-lg font-bold">
                        $
                        {(
                          ((form.getValues("loanAmount") * (0.06 / 12)) /
                            (1 - Math.pow(1 + 0.06 / 12, -form.getValues("loanTerm")))) *
                          form.getValues("loanTerm")
                        ).toFixed(2)}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-6">
              <h3 className="text-lg font-medium">Personal Information</h3>

              <div className="grid gap-4 sm:grid-cols-2">
                <FormField
                  control={form.control}
                  name="firstName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>First Name</FormLabel>
                      <FormControl>
                        <Input placeholder="John" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="lastName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Last Name</FormLabel>
                      <FormControl>
                        <Input placeholder="Doe" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Email</FormLabel>
                    <FormControl>
                      <Input type="email" placeholder="john.doe@example.com" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="phone"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Phone Number</FormLabel>
                    <FormControl>
                      <Input placeholder="(555) 123-4567" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
          )}

          {step === 3 && (
            <div className="space-y-6">
              <h3 className="text-lg font-medium">Address & Financial Information</h3>

              <FormField
                control={form.control}
                name="address"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Street Address</FormLabel>
                    <FormControl>
                      <Input placeholder="123 Main St" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="grid gap-4 sm:grid-cols-3">
                <FormField
                  control={form.control}
                  name="city"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>City</FormLabel>
                      <FormControl>
                        <Input placeholder="New York" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="state"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>State</FormLabel>
                      <FormControl>
                        <Input placeholder="NY" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="zipCode"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>ZIP Code</FormLabel>
                      <FormControl>
                        <Input placeholder="10001" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={form.control}
                name="employmentStatus"
                render={({ field }) => (
                  <FormItem className="flex flex-col">
                    <FormLabel>Employment Status</FormLabel>
                    <Popover>
                      <PopoverTrigger asChild>
                        <FormControl>
                          <Button
                            variant="outline"
                            role="combobox"
                            className={cn("w-full justify-between", !field.value && "text-muted-foreground")}
                          >
                            {field.value
                              ? employmentStatuses.find((status) => status.value === field.value)?.label
                              : "Select employment status"}
                            <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                          </Button>
                        </FormControl>
                      </PopoverTrigger>
                      <PopoverContent className="w-full p-0">
                        <Command>
                          <CommandInput placeholder="Search employment status..." />
                          <CommandList>
                            <CommandEmpty>No status found.</CommandEmpty>
                            <CommandGroup>
                              {employmentStatuses.map((status) => (
                                <CommandItem
                                  value={status.label}
                                  key={status.value}
                                  onSelect={() => {
                                    form.setValue("employmentStatus", status.value)
                                  }}
                                >
                                  <Check
                                    className={cn(
                                      "mr-2 h-4 w-4",
                                      status.value === field.value ? "opacity-100" : "opacity-0",
                                    )}
                                  />
                                  {status.label}
                                </CommandItem>
                              ))}
                            </CommandGroup>
                          </CommandList>
                        </Command>
                      </PopoverContent>
                    </Popover>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {form.watch("employmentStatus") !== "unemployed" &&
                form.watch("employmentStatus") !== "student" &&
                form.watch("employmentStatus") !== "" && (
                  <FormField
                    control={form.control}
                    name="employerName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Employer Name</FormLabel>
                        <FormControl>
                          <Input placeholder="Company Name" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                )}

              <FormField
                control={form.control}
                name="monthlyIncome"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Monthly Income</FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        placeholder="5000"
                        {...field}
                        onChange={(e) => field.onChange(Number.parseFloat(e.target.value) || 0)}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="creditScore"
                render={({ field }) => (
                  <FormItem className="space-y-3">
                    <FormLabel>Estimated Credit Score</FormLabel>
                    <FormControl>
                      <RadioGroup
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                        className="flex flex-col space-y-1"
                      >
                        <FormItem className="flex items-center space-x-3 space-y-0">
                          <FormControl>
                            <RadioGroupItem value="excellent" />
                          </FormControl>
                          <FormLabel className="font-normal">Excellent (720+)</FormLabel>
                        </FormItem>
                        <FormItem className="flex items-center space-x-3 space-y-0">
                          <FormControl>
                            <RadioGroupItem value="good" />
                          </FormControl>
                          <FormLabel className="font-normal">Good (680-719)</FormLabel>
                        </FormItem>
                        <FormItem className="flex items-center space-x-3 space-y-0">
                          <FormControl>
                            <RadioGroupItem value="fair" />
                          </FormControl>
                          <FormLabel className="font-normal">Fair (620-679)</FormLabel>
                        </FormItem>
                        <FormItem className="flex items-center space-x-3 space-y-0">
                          <FormControl>
                            <RadioGroupItem value="poor" />
                          </FormControl>
                          <FormLabel className="font-normal">Poor (below 620)</FormLabel>
                        </FormItem>
                      </RadioGroup>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
          )}

          {step === 4 && (
            <div className="space-y-6">
              <h3 className="text-lg font-medium">Additional Information & Review</h3>

              <FormField
                control={form.control}
                name="additionalInfo"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Additional Information (Optional)</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Please provide any additional information that might help us process your application."
                        className="min-h-[100px]"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="rounded-lg border p-4 space-y-4">
                <h4 className="font-medium">Application Summary</h4>

                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div className="text-muted-foreground">Loan Amount:</div>
                  <div>${form.getValues("loanAmount").toLocaleString()}</div>

                  <div className="text-muted-foreground">Loan Term:</div>
                  <div>{form.getValues("loanTerm")} months</div>

                  <div className="text-muted-foreground">Purpose:</div>
                  <div>
                    {purposes[loanType].find((p) => p.value === form.getValues("purpose"))?.label ||
                      form.getValues("purpose")}
                  </div>

                  <div className="text-muted-foreground">Full Name:</div>
                  <div>
                    {form.getValues("firstName")} {form.getValues("lastName")}
                  </div>

                  <div className="text-muted-foreground">Email:</div>
                  <div>{form.getValues("email")}</div>

                  <div className="text-muted-foreground">Phone:</div>
                  <div>{form.getValues("phone")}</div>

                  <div className="text-muted-foreground">Address:</div>
                  <div>
                    {form.getValues("address")}, {form.getValues("city")}, {form.getValues("state")}{" "}
                    {form.getValues("zipCode")}
                  </div>

                  <div className="text-muted-foreground">Employment Status:</div>
                  <div>
                    {employmentStatuses.find((s) => s.value === form.getValues("employmentStatus"))?.label ||
                      form.getValues("employmentStatus")}
                  </div>

                  <div className="text-muted-foreground">Monthly Income:</div>
                  <div>${form.getValues("monthlyIncome").toLocaleString()}</div>

                  <div className="text-muted-foreground">Credit Score:</div>
                  <div className="capitalize">{form.getValues("creditScore")}</div>
                </div>
              </div>

              <FormField
                control={form.control}
                name="agreeTerms"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                    <FormControl>
                      <Checkbox checked={field.value} onCheckedChange={field.onChange} />
                    </FormControl>
                    <div className="space-y-1 leading-none">
                      <FormLabel>I agree to the terms and conditions</FormLabel>
                      <FormDescription>
                        By submitting this application, I authorize LoanEase to check my credit and verify the
                        information provided.
                      </FormDescription>
                    </div>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
          )}

          <div className="flex justify-between">
            {step > 1 ? (
              <Button type="button" variant="outline" onClick={prevStep}>
                Previous
              </Button>
            ) : (
              <div></div>
            )}

            {step < totalSteps ? (
              <Button type="button" onClick={nextStep}>
                Next
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            ) : (
              <Button type="submit" disabled={isSubmitting}>
                {isSubmitting ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Submitting...
                  </>
                ) : (
                  <>Submit Application</>
                )}
              </Button>
            )}
          </div>
        </form>
      </Form>
    </div>
  )
}

