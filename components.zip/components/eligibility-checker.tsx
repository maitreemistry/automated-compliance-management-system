"use client"

import { useState } from "react"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import { z } from "zod"
import { ArrowRight, Check, Loader2, X } from "lucide-react"
import { useRouter } from "next/navigation"

import { Button } from "@/components/ui/button"
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Slider } from "@/components/ui/slider"
import { useToast } from "@/hooks/use-toast"

const formSchema = z.object({
  loanType: z.string().min(1, "Please select a loan type"),
  loanAmount: z.number().min(1000, "Minimum loan amount is $1,000").max(100000, "Maximum loan amount is $100,000"),
  creditScore: z.enum(["excellent", "good", "fair", "poor"]),
  monthlyIncome: z.number().min(1, "Please enter your monthly income"),
  employmentStatus: z.string().min(1, "Please select your employment status"),
})

type FormValues = z.infer<typeof formSchema>

export function EligibilityChecker() {
  const [isChecking, setIsChecking] = useState(false)
  const [result, setResult] = useState<null | {
    eligible: boolean
    loanTypes: string[]
    maxAmount: number
    estimatedRate: string
    reasons: string[]
  }>(null)
  const { toast } = useToast()
  const router = useRouter()

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      loanType: "",
      loanAmount: 10000,
      creditScore: "good",
      monthlyIncome: 0,
      employmentStatus: "",
    },
  })

  function onSubmit(data: FormValues) {
    setIsChecking(true)
    setResult(null)

    // Simulate API call to compliance and eligibility system
    setTimeout(() => {
      // Automated eligibility determination based on criteria
      const eligible = determineEligibility(data)

      setIsChecking(false)
      setResult(eligible)

      if (eligible.eligible) {
        toast({
          title: "Good news!",
          description: "You're eligible for a loan. See details below.",
        })
      } else {
        toast({
          title: "Eligibility Check Complete",
          description: "We've assessed your eligibility. See details below.",
          variant: "destructive",
        })
      }
    }, 2000)
  }

  function determineEligibility(data: FormValues) {
    // Simulate automated compliance and eligibility checks
    const creditScoreMap = {
      excellent: 750,
      good: 680,
      fair: 620,
      poor: 580,
    }

    const creditScoreValue = creditScoreMap[data.creditScore]
    const debtToIncomeRatio = (data.loanAmount / (data.monthlyIncome * 12)) * 100

    // Determine eligibility based on criteria
    const eligible =
      creditScoreValue >= 620 &&
      data.monthlyIncome >= 2000 &&
      debtToIncomeRatio <= 40 &&
      data.employmentStatus !== "unemployed"

    // Determine eligible loan types
    const loanTypes = []
    if (creditScoreValue >= 700) {
      loanTypes.push("Personal Loan", "Auto Loan", "Home Improvement Loan")
    } else if (creditScoreValue >= 650) {
      loanTypes.push("Personal Loan", "Auto Loan")
    } else if (creditScoreValue >= 620) {
      loanTypes.push("Personal Loan")
    }

    // Calculate max loan amount
    const maxAmount = Math.min(data.monthlyIncome * 12 * 0.4, 50000)

    // Estimate interest rate
    let estimatedRate = ""
    if (creditScoreValue >= 750) estimatedRate = "5.99% - 8.99%"
    else if (creditScoreValue >= 700) estimatedRate = "7.99% - 10.99%"
    else if (creditScoreValue >= 650) estimatedRate = "9.99% - 14.99%"
    else estimatedRate = "14.99% - 19.99%"

    // Provide reasons if not eligible
    const reasons = []
    if (creditScoreValue < 620) reasons.push("Credit score below minimum requirement")
    if (data.monthlyIncome < 2000) reasons.push("Monthly income below minimum requirement")
    if (debtToIncomeRatio > 40) reasons.push("Requested loan amount too high for your income")
    if (data.employmentStatus === "unemployed") reasons.push("Current employment status does not meet requirements")

    return {
      eligible,
      loanTypes,
      maxAmount,
      estimatedRate,
      reasons,
    }
  }

  function handleApplyNow() {
    router.push(`/apply?type=${form.getValues("loanType")}&amount=${form.getValues("loanAmount")}`)
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Check Your Eligibility</CardTitle>
        <CardDescription>Find out which loans you qualify for in seconds</CardDescription>
      </CardHeader>
      <CardContent>
        {!result ? (
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <FormField
                control={form.control}
                name="loanType"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Loan Type</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select loan type" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="personal">Personal Loan</SelectItem>
                        <SelectItem value="auto">Auto Loan</SelectItem>
                        <SelectItem value="home">Home Improvement Loan</SelectItem>
                        <SelectItem value="business">Business Loan</SelectItem>
                        <SelectItem value="mortgage">Mortgage</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="loanAmount"
                render={({ field }) => (
                  <FormItem className="space-y-4">
                    <div className="flex items-center justify-between">
                      <FormLabel>Loan Amount</FormLabel>
                      <span className="text-sm font-medium">${field.value.toLocaleString()}</span>
                    </div>
                    <FormControl>
                      <Slider
                        min={1000}
                        max={100000}
                        step={1000}
                        value={[field.value]}
                        onValueChange={(value) => field.onChange(value[0])}
                      />
                    </FormControl>
                    <div className="flex justify-between text-xs text-muted-foreground">
                      <span>$1,000</span>
                      <span>$100,000</span>
                    </div>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="creditScore"
                render={({ field }) => (
                  <FormItem className="space-y-3">
                    <FormLabel>Estimated Credit Score</FormLabel>
                    <FormControl>
                      <RadioGroup
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                        className="flex flex-col space-y-1"
                      >
                        <FormItem className="flex items-center space-x-3 space-y-0">
                          <FormControl>
                            <RadioGroupItem value="excellent" />
                          </FormControl>
                          <FormLabel className="font-normal">Excellent (720+)</FormLabel>
                        </FormItem>
                        <FormItem className="flex items-center space-x-3 space-y-0">
                          <FormControl>
                            <RadioGroupItem value="good" />
                          </FormControl>
                          <FormLabel className="font-normal">Good (680-719)</FormLabel>
                        </FormItem>
                        <FormItem className="flex items-center space-x-3 space-y-0">
                          <FormControl>
                            <RadioGroupItem value="fair" />
                          </FormControl>
                          <FormLabel className="font-normal">Fair (620-679)</FormLabel>
                        </FormItem>
                        <FormItem className="flex items-center space-x-3 space-y-0">
                          <FormControl>
                            <RadioGroupItem value="poor" />
                          </FormControl>
                          <FormLabel className="font-normal">Poor (below 620)</FormLabel>
                        </FormItem>
                      </RadioGroup>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="monthlyIncome"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Monthly Income</FormLabel>
                    <FormControl>
                      <div className="relative">
                        <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">$</span>
                        <Input
                          type="number"
                          className="pl-7"
                          placeholder="5000"
                          {...field}
                          onChange={(e) => field.onChange(Number.parseFloat(e.target.value) || 0)}
                        />
                      </div>
                    </FormControl>
                    <FormDescription>Your gross monthly income before taxes</FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="employmentStatus"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Employment Status</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select employment status" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="full-time">Full-time</SelectItem>
                        <SelectItem value="part-time">Part-time</SelectItem>
                        <SelectItem value="self-employed">Self-employed</SelectItem>
                        <SelectItem value="retired">Retired</SelectItem>
                        <SelectItem value="unemployed">Unemployed</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <Button type="submit" className="w-full" disabled={isChecking}>
                {isChecking ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Checking Eligibility...
                  </>
                ) : (
                  <>Check Eligibility</>
                )}
              </Button>
            </form>
          </Form>
        ) : (
          <div className="space-y-6">
            <div className="flex items-center justify-center">
              {result.eligible ? (
                <div className="flex h-16 w-16 items-center justify-center rounded-full bg-green-100">
                  <Check className="h-8 w-8 text-green-600" />
                </div>
              ) : (
                <div className="flex h-16 w-16 items-center justify-center rounded-full bg-red-100">
                  <X className="h-8 w-8 text-red-600" />
                </div>
              )}
            </div>

            <div className="text-center">
              <h3 className="text-xl font-bold">{result.eligible ? "You're Pre-Qualified!" : "We're Sorry"}</h3>
              <p className="text-muted-foreground">
                {result.eligible
                  ? "Based on the information provided, you're eligible for the following loans:"
                  : "Based on the information provided, you don't currently meet our eligibility criteria."}
              </p>
            </div>

            {result.eligible ? (
              <div className="space-y-4">
                <div className="rounded-lg border p-4">
                  <div className="grid grid-cols-2 gap-2">
                    <div className="text-sm text-muted-foreground">Eligible Loan Types:</div>
                    <div className="text-sm font-medium">{result.loanTypes.join(", ")}</div>

                    <div className="text-sm text-muted-foreground">Maximum Loan Amount:</div>
                    <div className="text-sm font-medium">${result.maxAmount.toLocaleString()}</div>

                    <div className="text-sm text-muted-foreground">Estimated Interest Rate:</div>
                    <div className="text-sm font-medium">{result.estimatedRate}</div>
                  </div>
                </div>

                <Button className="w-full" onClick={handleApplyNow}>
                  Apply Now <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="rounded-lg border p-4">
                  <h4 className="font-medium mb-2">Reasons:</h4>
                  <ul className="space-y-1 text-sm">
                    {result.reasons.map((reason, index) => (
                      <li key={index} className="flex items-start">
                        <span className="mr-2">•</span>
                        <span>{reason}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <Button variant="outline" className="w-full" onClick={() => setResult(null)}>
                  Try Again
                </Button>
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  )
}

