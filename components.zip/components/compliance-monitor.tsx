"use client"

import { AlertCircle, CheckCircle, Shield } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { cn } from "@/lib/utils"

interface ComplianceStatus {
  kycVerified: boolean
  amlChecked: boolean
  regulatoryCompliant: boolean
  dataProtectionCompliant: boolean
  overallCompliant: boolean
  flags: string[]
}

interface ComplianceMonitorProps {
  status: ComplianceStatus
  className?: string
}

export function ComplianceMonitor({ status, className }: ComplianceMonitorProps) {
  return (
    <div className={cn("space-y-3", className)}>
      <div className="flex items-center gap-2">
        <Shield className="h-5 w-5 text-primary" />
        <h3 className="font-medium">Automated Compliance Monitor</h3>
      </div>

      <div className="grid grid-cols-2 gap-2 text-sm">
        <div className="flex items-center gap-2">
          {status.kycVerified ? (
            <CheckCircle className="h-4 w-4 text-green-500" />
          ) : (
            <AlertCircle className="h-4 w-4 text-amber-500" />
          )}
          <span>KYC Verification</span>
        </div>

        <div className="flex items-center gap-2">
          {status.amlChecked ? (
            <CheckCircle className="h-4 w-4 text-green-500" />
          ) : (
            <AlertCircle className="h-4 w-4 text-amber-500" />
          )}
          <span>AML Screening</span>
        </div>

        <div className="flex items-center gap-2">
          {status.regulatoryCompliant ? (
            <CheckCircle className="h-4 w-4 text-green-500" />
          ) : (
            <AlertCircle className="h-4 w-4 text-amber-500" />
          )}
          <span>Regulatory Compliance</span>
        </div>

        <div className="flex items-center gap-2">
          {status.dataProtectionCompliant ? (
            <CheckCircle className="h-4 w-4 text-green-500" />
          ) : (
            <AlertCircle className="h-4 w-4 text-amber-500" />
          )}
          <span>Data Protection</span>
        </div>
      </div>

      {status.flags.length > 0 && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Compliance Issues Detected</AlertTitle>
          <AlertDescription>
            <ul className="mt-2 space-y-1 text-sm">
              {status.flags.map((flag, index) => (
                <li key={index}>{flag}</li>
              ))}
            </ul>
          </AlertDescription>
        </Alert>
      )}

      <div className="flex items-center justify-between">
        <span className="text-sm font-medium">Overall Compliance Status:</span>
        <Badge variant={status.overallCompliant ? "default" : "destructive"}>
          {status.overallCompliant ? "Compliant" : "Action Required"}
        </Badge>
      </div>
    </div>
  )
}

